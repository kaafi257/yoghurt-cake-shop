/* SweetCraft delivery control centre (owner / manager): what needs attention + live driver status.
   Adds itself above the Board; reads the same data as /delivery/index.html. */
(function () {
  'use strict';
  var st = (typeof seenAge === 'function') ? seenAge : function () { return 1e9; };
  function el() {
    var c = document.getElementById('ctl'); if (c) return c;
    var anchor = document.getElementById('chips'); if (!anchor || !anchor.parentNode) return null;
    c = document.createElement('div'); c.id = 'ctl'; anchor.parentNode.insertBefore(c, anchor); return c;
  }
  function alerts() {
    var A = [], dl = orders.filter(function (o) { return isDel(o) && live(o); });
    dl.forEach(function (o) {
      var m = minsSince(o.created_at), nm = esc(short(o)) + ' · ' + esc(o.customer_name);
      if (o.status === 'new' && m >= 5) A.push({ r: m >= 15 ? 0 : 2, lv: m >= 15 ? 'bad' : '', t: nm, s: 'Waiting ' + fmtMin(m) + ' to be confirmed', b: 'Confirm', a: "move('" + o.id + "','confirmed')" });
      if (!o.driver_id && o.status !== 'new' && m >= 3) A.push({ r: 1, lv: m >= 10 ? 'bad' : '', t: nm, s: 'No driver yet · ' + fmtMin(m) + ' since the order', b: 'Auto-assign', a: "autoAssign('" + o.id + "')" });
      if (o.status === 'preparing' && o.driver_id && m >= 35) A.push({ r: 3, lv: '', t: nm, s: 'Still preparing after ' + fmtMin(m), b: 'Open', a: "Ctl.open('" + o.id + "')" });
      if (o.status === 'out_for_delivery' && m >= 70) A.push({ r: 2, lv: m >= 100 ? 'bad' : '', t: nm, s: 'On the road for a long time (' + fmtMin(m) + ' since the order)', b: 'On map', a: "goMap('" + o.id + "')" });
      if (o.payment_method === 'online' && o.payment_status !== 'paid' && m >= 5) A.push({ r: 4, lv: 'info', t: nm, s: 'Telebirr payment not confirmed yet' + (o.payment_ref ? ' · ID ' + esc(o.payment_ref) : ''), b: 'Payment received', a: "paid('" + o.id + "')" });
      if (!dest(o)) A.push({ r: 2, lv: 'bad', t: nm, s: 'No map pin. The driver cannot navigate', b: 'Set place', a: "editPlace('" + o.id + "')" });
    });
    drivers.forEach(function (d) {
      var onRoad = dl.some(function (o) { return o.driver_id === d.id && o.status === 'out_for_delivery'; });
      if (onRoad && st(d.seen_at) > 120) A.push({ r: 1, lv: 'bad', t: esc(d.name), s: 'On a delivery but location lost for ' + (st(d.seen_at) > 3600 ? 'over an hour' : fmtMin(Math.round(st(d.seen_at) / 60))), b: 'Open map', a: "Ctl.driver('" + d.id + "')" });
    });
    return A.sort(function (a, b) { return a.r - b.r; });
  }
  function driverCard(d) {
    var a = st(d.seen_at), c = a < 90 ? 'live' : a < 600 ? 'stale' : '', jobs = orders.filter(function (o) { return isDel(o) && live(o) && o.driver_id === d.id; });
    var road = jobs.filter(function (o) { return o.status === 'out_for_delivery'; }), cur = road[0] || jobs[0];
    var cash = road.filter(function (o) { return o.payment_method === 'cod' && o.payment_status !== 'paid'; }).reduce(function (t, o) { return t + Number(o.total); }, 0);
    var line = 'Free · no active jobs';
    if (cur) { var far = d.lat != null && dest(cur) && cur.status === 'out_for_delivery' ? SCMap.dist(d, dest(cur)) : null;
      line = '<b>' + esc(short(cur)) + '</b> ' + esc(cur.customer_name) + '<br>' + esc(STAT[cur.status]) + (far != null ? ' · ' + fmtDist(far) + ' away · ~' + eta(far) : '') + (jobs.length > 1 ? '<br>+' + (jobs.length - 1) + ' more' : ''); }
    var seen = d.seen_at ? (a < 90 ? 'Live now' : 'Seen ' + ago(d.seen_at)) : 'Never shared location';
    return '<div class="dr" onclick="Ctl.driver(\'' + d.id + '\')"><div class="t"><div class="av2">' + esc(initials(d.name)) + '</div><div><b>' + esc(d.name) + '</b><small>' + seen + '</small></div><span class="dt ' + c + '"></span></div><div class="j">' + line + (cash ? '<br><span class="cash">💵 ' + etb(cash) + ' to collect</span>' : '') + '</div></div>';
  }
  function render() {
    if (!dispatch) return; var c = el(); if (!c) return;
    var A = alerts(), shown = A.slice(0, 6);
    var h = '<div class="ctl-h"><h3>Needs your attention' + (A.length ? ' (' + A.length + ')' : '') + '</h3></div>' +
      (shown.length ? shown.map(function (x) { return '<div class="al ' + x.lv + '"><div><b>' + x.t + '</b>' + x.s + '</div><button class="' + (x.lv === 'bad' ? 'primary' : '') + '" onclick="' + x.a + '">' + x.b + '</button></div>'; }).join('') + (A.length > 6 ? '<div class="mut" style="text-align:center">+' + (A.length - 6) + ' more below in the list</div>' : '')
        : '<div class="al-ok">✅ All good. Nothing is waiting too long.</div>');
    if (drivers.length) h += '<div class="ctl-h" style="margin-top:14px"><h3>Drivers</h3></div><div class="drs">' + drivers.map(driverCard).join('') + '</div>';
    c.innerHTML = h;
  }
  window.Ctl = {
    open: function (id) { bf = 'active'; bq = String(orders.find(function (o) { return o.id === id; }).order_no); try { $('bsearch').value = bq; } catch (e) {} renderBoard(); window.scrollTo({ top: 0, behavior: 'smooth' }); },
    driver: function (id) { showTab('map'); setTimeout(function () { selectFromList('d', id); }, 60); }
  };
  var _ra = window.renderAll; if (typeof _ra === 'function') window.renderAll = function () { var r = _ra.apply(this, arguments); try { render(); } catch (e) { console.error(e); } return r; };
  try { if (me && dispatch && orders.length) render(); } catch (e) {}
  setInterval(function () { try { if (me && dispatch && typeof tab !== 'undefined' && tab === 'board') render(); } catch (e) {} }, 15000);
})();
