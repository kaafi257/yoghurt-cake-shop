/* SweetCraft mini map: OpenStreetMap tiles, drag / pinch / wheel zoom, markers and lines.
   No library and no API key. Used by /delivery/ and /track/.
   Map data (c) OpenStreetMap contributors. Tiles come from tile.openstreetmap.org (light use only;
   switch TILE_URL to a paid tile provider if the shop ever has heavy traffic). */
(function (G) {
  var TS = 256, MINZ = 3, MAXZ = 19;
  var TILE_URL = 'https://tile.openstreetmap.org/{z}/{x}/{y}.png';
  var R = Math.PI / 180;

  function wx(lng, z) { return (lng + 180) / 360 * TS * Math.pow(2, z); }
  function wy(lat, z) {
    var s = Math.sin(Math.max(-85.05, Math.min(85.05, lat)) * R);
    return (0.5 - Math.log((1 + s) / (1 - s)) / (4 * Math.PI)) * TS * Math.pow(2, z);
  }
  function ilng(x, z) { return x / (TS * Math.pow(2, z)) * 360 - 180; }
  function ilat(y, z) { var n = Math.PI - 2 * Math.PI * y / (TS * Math.pow(2, z)); return Math.atan(Math.sinh(n)) / R; }
  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }

  /** distance in metres between two {lat,lng} */
  function dist(a, b) {
    var dLat = (b.lat - a.lat) * R, dLng = (b.lng - a.lng) * R;
    var h = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(a.lat * R) * Math.cos(b.lat * R) * Math.sin(dLng / 2) * Math.sin(dLng / 2);
    return 2 * 6371000 * Math.asin(Math.sqrt(h));
  }

  function el(tag, cls, css) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (css) e.style.cssText = css;
    return e;
  }

  function SCMap(root, opt) {
    opt = opt || {};
    var self = this;
    self.root = root;
    self.lat = opt.lat != null ? opt.lat : 9.03;     // Addis Ababa
    self.lng = opt.lng != null ? opt.lng : 38.74;
    self.z = opt.z || 13;
    self.handlers = {};
    self.markers = {};
    self.lines = {};
    self.tiles = {};

    root.classList.add('scmap');
    root.innerHTML = '';
    self.tileLayer = el('div', 'scmap-tiles');
    self.svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    self.svg.setAttribute('class', 'scmap-svg');
    self.markerLayer = el('div', 'scmap-markers');
    var zoom = el('div', 'scmap-zoom');
    var zi = el('button', '', ''); zi.type = 'button'; zi.textContent = '+'; zi.setAttribute('aria-label', 'Zoom in');
    var zo = el('button', '', ''); zo.type = 'button'; zo.textContent = '−'; zo.setAttribute('aria-label', 'Zoom out');
    zoom.appendChild(zi); zoom.appendChild(zo);
    var attr = el('div', 'scmap-attr');
    attr.innerHTML = '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a>';
    root.appendChild(self.tileLayer); root.appendChild(self.svg); root.appendChild(self.markerLayer);
    root.appendChild(zoom); root.appendChild(attr);
    self.controls = zoom;

    zi.onclick = function (e) { e.stopPropagation(); self.zoomAt(1, self.w / 2, self.h / 2); };
    zo.onclick = function (e) { e.stopPropagation(); self.zoomAt(-1, self.w / 2, self.h / 2); };
    ['pointerdown', 'dblclick'].forEach(function (t) { zoom.addEventListener(t, function (e) { e.stopPropagation(); }); });

    self._size();
    if (G.ResizeObserver) new ResizeObserver(function () { self._size(); self.render(); }).observe(root);
    else G.addEventListener('resize', function () { self._size(); self.render(); });
    self._bind();
    self.render();
  }

  var P = SCMap.prototype;

  P._size = function () { this.w = this.root.clientWidth || 300; this.h = this.root.clientHeight || 300; };
  P.on = function (name, fn) { this.handlers[name] = fn; return this; };
  P._emit = function (name, a, b) { if (this.handlers[name]) this.handlers[name](a, b); };

  P._topLeft = function () {
    return { x: wx(this.lng, this.z) - this.w / 2, y: wy(this.lat, this.z) - this.h / 2 };
  };
  P._pt = function (lat, lng, tl) { return { x: wx(lng, this.z) - tl.x, y: wy(lat, this.z) - tl.y }; };
  P.project = function (lat, lng) { return this._pt(lat, lng, this._topLeft()); };
  P.unproject = function (px, py) {
    var tl = this._topLeft();
    return { lat: ilat(tl.y + py, this.z), lng: ilng(tl.x + px, this.z) };
  };

  P.setView = function (lat, lng, z) {
    this.lat = clamp(lat, -85, 85); this.lng = lng;
    if (z != null) { if (z !== this.z) this._clearTiles(); this.z = clamp(Math.round(z), MINZ, MAXZ); }
    this.render();
  };

  P.zoomAt = function (dz, px, py) {
    var nz = clamp(this.z + dz, MINZ, MAXZ);
    if (nz === this.z) return;
    var tl = this._topLeft();
    var k = Math.pow(2, nz - this.z);
    var nx = (tl.x + px) * k - px + this.w / 2;
    var ny = (tl.y + py) * k - py + this.h / 2;
    this._clearTiles();
    this.z = nz;
    this.lng = ilng(nx, nz); this.lat = clamp(ilat(ny, nz), -85, 85);
    this.render();
    this._emit('move');
  };

  P._panBy = function (dx, dy) {
    var cx = wx(this.lng, this.z) - dx, cy = wy(this.lat, this.z) - dy;
    this.lng = ilng(cx, this.z); this.lat = clamp(ilat(cy, this.z), -85, 85);
    this.render();
  };

  /** points: [{lat,lng}], fits them all into view */
  P.fit = function (points, pad) {
    pad = pad == null ? 48 : pad;
    var pts = (points || []).filter(function (p) { return p && isFinite(p.lat) && isFinite(p.lng); });
    if (!pts.length) return;
    var minLat = 90, maxLat = -90, minLng = 180, maxLng = -180;
    pts.forEach(function (p) {
      minLat = Math.min(minLat, p.lat); maxLat = Math.max(maxLat, p.lat);
      minLng = Math.min(minLng, p.lng); maxLng = Math.max(maxLng, p.lng);
    });
    var cLat = (minLat + maxLat) / 2, cLng = (minLng + maxLng) / 2, z = 16;
    this._size();
    var aw = Math.max(40, this.w - pad * 2), ah = Math.max(40, this.h - pad * 2);
    for (; z > MINZ; z--) {
      var dx = Math.abs(wx(maxLng, z) - wx(minLng, z)), dy = Math.abs(wy(minLat, z) - wy(maxLat, z));
      if (dx <= aw && dy <= ah) break;
    }
    this.setView(cLat, cLng, z);
  };

  /* ---- tiles ---- */
  P._clearTiles = function () {
    for (var k in this.tiles) { if (this.tiles[k].parentNode) this.tiles[k].parentNode.removeChild(this.tiles[k]); }
    this.tiles = {};
  };

  P.render = function () {
    var z = this.z, tl = this._topLeft(), n = Math.pow(2, z), want = {};
    var x0 = Math.floor(tl.x / TS), x1 = Math.floor((tl.x + this.w) / TS);
    var y0 = Math.max(0, Math.floor(tl.y / TS)), y1 = Math.min(n - 1, Math.floor((tl.y + this.h) / TS));
    for (var x = x0; x <= x1; x++) {
      for (var y = y0; y <= y1; y++) {
        var tx = ((x % n) + n) % n, key = x + '/' + y;
        want[key] = 1;
        var img = this.tiles[key];
        if (!img) {
          img = new Image();
          img.alt = ''; img.draggable = false; img.className = 'scmap-tile';
          img.onerror = function () { this.style.visibility = 'hidden'; };
          img.src = TILE_URL.replace('{z}', z).replace('{x}', tx).replace('{y}', y);
          this.tileLayer.appendChild(img);
          this.tiles[key] = img;
        }
        img.style.transform = 'translate(' + Math.round(x * TS - tl.x) + 'px,' + Math.round(y * TS - tl.y) + 'px)';
      }
    }
    for (var k in this.tiles) {
      if (!want[k]) { var im = this.tiles[k]; if (im.parentNode) im.parentNode.removeChild(im); delete this.tiles[k]; }
    }
    this._place(tl);
  };

  /* ---- markers and lines ---- */
  /** html: marker content; anchor: 'center' (default) or 'bottom' (pin tip) */
  P.setMarker = function (id, lat, lng, o) {
    o = o || {};
    var m = this.markers[id];
    if (!m) {
      var node = el('div', 'scmap-mk' + (o.cls ? ' ' + o.cls : ''));
      var inner = el('div', 'scmap-mk-in');
      node.appendChild(inner);
      this.markerLayer.appendChild(node);
      m = this.markers[id] = { node: node, inner: inner };
      var self = this;
      node.addEventListener('pointerdown', function (e) { e.stopPropagation(); });
      node.addEventListener('click', function (e) { e.stopPropagation(); self._emit('markerclick', id); });
    }
    m.lat = lat; m.lng = lng;
    m.node.className = 'scmap-mk' + (o.cls ? ' ' + o.cls : '');
    if (o.html != null && m.html !== o.html) { m.inner.innerHTML = o.html; m.html = o.html; }
    m.inner.style.transform = o.anchor === 'bottom' ? 'translate(-50%,-100%)' : 'translate(-50%,-50%)';
    m.node.style.zIndex = o.z || 1;
    this._place(this._topLeft());
  };
  P.removeMarker = function (id) {
    var m = this.markers[id]; if (!m) return;
    if (m.node.parentNode) m.node.parentNode.removeChild(m.node);
    delete this.markers[id];
  };
  P.clearMarkers = function (keep) {
    for (var id in this.markers) { if (!keep || !keep[id]) this.removeMarker(id); }
  };

  /** pts: [[lat,lng],...]; style: {color,width,dash,opacity} */
  P.setLine = function (id, pts, style) {
    var l = this.lines[id];
    if (!l) {
      var path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
      path.setAttribute('fill', 'none'); path.setAttribute('stroke-linecap', 'round'); path.setAttribute('stroke-linejoin', 'round');
      this.svg.appendChild(path);
      l = this.lines[id] = { path: path };
    }
    l.pts = pts || [];
    style = style || {};
    l.path.setAttribute('stroke', style.color || '#6B1D2F');
    l.path.setAttribute('stroke-width', style.width || 4);
    l.path.setAttribute('stroke-opacity', style.opacity != null ? style.opacity : 0.85);
    if (style.dash) l.path.setAttribute('stroke-dasharray', style.dash); else l.path.removeAttribute('stroke-dasharray');
    this._place(this._topLeft());
  };
  P.removeLine = function (id) {
    var l = this.lines[id]; if (!l) return;
    if (l.path.parentNode) l.path.parentNode.removeChild(l.path);
    delete this.lines[id];
  };

  P._place = function (tl) {
    var id, m, p;
    for (id in this.markers) {
      m = this.markers[id]; p = this._pt(m.lat, m.lng, tl);
      m.node.style.transform = 'translate(' + Math.round(p.x) + 'px,' + Math.round(p.y) + 'px)';
    }
    for (id in this.lines) {
      var l = this.lines[id], d = '';
      for (var i = 0; i < l.pts.length; i++) {
        p = this._pt(l.pts[i][0], l.pts[i][1], tl);
        d += (i ? 'L' : 'M') + p.x.toFixed(1) + ' ' + p.y.toFixed(1);
      }
      l.path.setAttribute('d', d);
    }
  };

  /* ---- gestures ---- */
  P._bind = function () {
    var self = this, root = this.root, ptrs = {}, moved = 0, startPinch = 0, down = null, lastWheel = 0;
    function count() { return Object.keys(ptrs).length; }
    function two() { var k = Object.keys(ptrs); return [ptrs[k[0]], ptrs[k[1]]]; }
    function d2(a, b) { return Math.hypot(a.x - b.x, a.y - b.y); }

    root.addEventListener('pointerdown', function (e) {
      if (e.button != null && e.button > 0) return;
      try { root.setPointerCapture(e.pointerId); } catch (x) {}
      var r = root.getBoundingClientRect();
      ptrs[e.pointerId] = { x: e.clientX - r.left, y: e.clientY - r.top };
      if (count() === 1) { moved = 0; down = { x: ptrs[e.pointerId].x, y: ptrs[e.pointerId].y }; }
      if (count() === 2) { var t = two(); startPinch = d2(t[0], t[1]); moved = 99; }
    });
    root.addEventListener('pointermove', function (e) {
      var p = ptrs[e.pointerId]; if (!p) return;
      var r = root.getBoundingClientRect(), nx = e.clientX - r.left, ny = e.clientY - r.top;
      if (count() === 1) {
        moved += Math.abs(nx - p.x) + Math.abs(ny - p.y);
        if (moved > 6) { self._panBy(nx - p.x, ny - p.y); }
        p.x = nx; p.y = ny;
      } else if (count() === 2) {
        p.x = nx; p.y = ny;
        var t = two(), d = d2(t[0], t[1]), mx = (t[0].x + t[1].x) / 2, my = (t[0].y + t[1].y) / 2;
        if (startPinch && d / startPinch > 1.6) { self.zoomAt(1, mx, my); startPinch = d; }
        else if (startPinch && d / startPinch < 0.62) { self.zoomAt(-1, mx, my); startPinch = d; }
      }
    });
    function up(e) {
      var had = ptrs[e.pointerId]; if (!had) return;
      delete ptrs[e.pointerId];
      if (count() === 0 && e.type === 'pointerup' && moved <= 6 && down) {
        var p = self.unproject(down.x, down.y);
        self._emit('click', p.lat, p.lng);
      }
      if (count() === 0) { down = null; self._emit('move'); }
    }
    root.addEventListener('pointerup', up);
    root.addEventListener('pointercancel', up);
    root.addEventListener('wheel', function (e) {
      e.preventDefault();
      var now = Date.now(); if (now - lastWheel < 180) return; lastWheel = now;
      var r = root.getBoundingClientRect();
      self.zoomAt(e.deltaY < 0 ? 1 : -1, e.clientX - r.left, e.clientY - r.top);
    }, { passive: false });
    root.addEventListener('dblclick', function (e) {
      var r = root.getBoundingClientRect();
      self.zoomAt(1, e.clientX - r.left, e.clientY - r.top);
    });
  };

  SCMap.dist = dist;
  G.SCMap = SCMap;
})(window);
