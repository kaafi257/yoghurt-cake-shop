/* SweetCraft driving mode. Big full-screen navigation for the rider.
   Road directions come from the free public OSRM service (OpenStreetMap data); if it is not reachable the
   screen falls back to a straight line and the "Google Maps" button. Needs /delivery/index.html globals. */
(function () {
  'use strict';
  var ov, map, jobId = null, route = null, routeKey = '', lastFetch = 0, rid = 0, fetching = false, noRoute = false;
  var mini = false, follow = true, pauseAt = 0, idx = 1, tmr = null, said = {}, expanded = false, lastH = null, prev = null, lastZ = 0, sig = '';
  var voice = ls.get('sc_voice') !== '0', night = ls.get('sc_night') === '1';
  var $d = function (id) { return document.getElementById(id); };
  var P = function () { return typeof myPos !== 'undefined' ? myPos : null; };
  var ANG = { 'straight': 0, 'slight right': 40, 'right': 90, 'sharp right': 140, 'uturn': 180, 'sharp left': -140, 'left': -90, 'slight left': -40 };
  var ARW = '<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20V5M5 12l7-7 7 7"/></svg>';
  var ME = '<svg viewBox="0 0 44 44"><circle cx="22" cy="22" r="19" fill="#1f5fbf" stroke="#fff" stroke-width="3"/><path d="M22 9l9 21-9-5-9 5z" fill="#fff"/></svg>';

  var PIN = function (icon, col) { return '<svg viewBox="0 0 40 52" width="42" height="55" style="display:block;filter:drop-shadow(0 3px 4px #0006)"><path d="M20 1.5C10 1.5 2 9.5 2 19.5c0 13 18 31 18 31s18-18 18-31c0-10-8-18-18-18z" fill="' + col + '" stroke="#fff" stroke-width="2.5"/>' + icon + '</svg>'; };
  var HOME = '<path d="M11 21l9-8 9 8v8h-6v-6h-6v6h-6z" fill="#fff"/>';
  var STORE = '<path d="M11 13h18l1.6 6H9.400zM11 21h18v9H11z" fill="#fff"/><rect x="17" y="24" width="6" height="6" fill="#111"/>';
  var pvKey = '';
  function isPV(o) { return o && o.status !== 'out_for_delivery'; }
  function nItems(o) { return (o.online_order_items || []).reduce(function (t, i) { return t + Number(i.quantity || 0); }, 0); }
  function shopPt() { try { return typeof SHOP !== 'undefined' && SHOP ? { lat: SHOP.lat, lng: SHOP.lng } : null; } catch (e) { return null; } }

  function targets() {
    if (!me) return [];
    var p = P();
    return orders.filter(function (o) { return isDel(o) && o.driver_id === me.id && dest(o) && ['out_for_delivery', 'preparing'].indexOf(o.status) >= 0; })
      .sort(function (a, b) {
        var ra = a.status === 'out_for_delivery' ? 0 : 1, rb = b.status === 'out_for_delivery' ? 0 : 1;
        if (ra !== rb) return ra - rb;
        return p ? SCMap.dist(p, dest(a)) - SCMap.dist(p, dest(b)) : new Date(a.created_at) - new Date(b.created_at);
      });
  }
  function bearing(a, b) {
    var R = Math.PI / 180, y = Math.sin((b.lng - a.lng) * R) * Math.cos(b.lat * R),
      x = Math.cos(a.lat * R) * Math.sin(b.lat * R) - Math.sin(a.lat * R) * Math.cos(b.lat * R) * Math.cos((b.lng - a.lng) * R);
    return (Math.atan2(y, x) / R + 360) % 360;
  }
  function stepText(s) {
    var m = s.maneuver || {}, t = m.type, mod = m.modifier || '', nm = s.name ? ' onto ' + s.name : '';
    if (t === 'arrive') return 'You are arriving at the customer';
    if (t === 'depart') return 'Head out' + (s.name ? ' on ' + s.name : '');
    if (t === 'roundabout' || t === 'rotary' || t === 'roundabout turn') return 'At the roundabout take exit ' + (m.exit || '') + (s.name ? ' onto ' + s.name : '');
    if (mod === 'uturn') return 'Make a U-turn';
    if (t === 'fork') return 'Keep ' + (mod.replace('slight ', '') || 'straight') + ' at the fork';
    if (mod === 'straight' || !mod) return 'Continue straight' + (s.name ? ' on ' + s.name : '');
    return 'Turn ' + mod + nm;
  }
  function spk(t) {
    if (!voice || !('speechSynthesis' in window)) return;
    try { speechSynthesis.cancel(); var u = new SpeechSynthesisUtterance(t); u.lang = 'en-US'; u.rate = 1; speechSynthesis.speak(u); } catch (e) {}
  }
  var rnd = function (m) { return m < 1000 ? Math.max(10, Math.round(m / 10) * 10) + ' m' : (m / 1000).toFixed(1) + ' km'; };
  var rndSay = function (m) { return m < 1000 ? Math.max(10, Math.round(m / 10) * 10) + ' meters' : (m / 1000).toFixed(1) + ' kilometers'; };

  function build() {
    ov = document.createElement('div'); ov.id = 'drive'; ov.className = 'hide';
    ov.innerHTML = '<div class="dv-top" id="dvTop"><div class="dv-arrow" id="dvArrow"></div><div class="dv-ti"><b id="dvDist">…</b><span id="dvText">Starting…</span></div>' +
      '<button class="dv-ib" id="dvVoice" aria-label="Voice">🔊</button><button class="dv-ib" id="dvX" aria-label="Close">✕</button></div>' +
      '<div id="dvmap"></div><div class="dv-banner" id="dvBan"></div>' +
      '<div class="dv-fabs"><button id="dvRe" aria-label="Centre on me">◎</button><button id="dvNight" aria-label="Day or night map">🌙</button></div>' +
      '<button class="dv-pvx" id="dvX2">✕ Close</button><div class="dv-sheet" id="dvSheet"></div>';
    document.body.appendChild(ov);
    $d('dvX').onclick = close; $d('dvX2').onclick = close; $d('dvVoice').onclick = function () { voice = !voice; ls.set('sc_voice', voice ? '1' : '0'); if (!voice && 'speechSynthesis' in window) speechSynthesis.cancel(); ui(); if (voice) spk('Voice directions on'); };
    $d('dvRe').onclick = function () { follow = true; pauseAt = 0; pvKey = ''; camera(true); ui(); };
    $d('dvNight').onclick = function () { night = !night; ls.set('sc_night', night ? '1' : '0'); ui(); };
  }
  function open(id) {
    if (!me) return;
    var list = targets();
    if (!list.length) { say('You have no delivery with a map pin to drive to.'); return; }
    jobId = (id && list.some(function (o) { return o.id === id; })) ? id : list[0].id;
    if (!ov) build();
    ov.classList.remove('hide'); document.body.style.overflow = 'hidden';
    if (typeof watchId !== 'undefined' && watchId == null) startGPS();
    try { requestWake(); } catch (e) {}
    if (!map) { map = new SCMap($d('dvmap'), { lat: DEF.lat, lng: DEF.lng, z: 16 }); map.on('move', function () { follow = false; pauseAt = Date.now(); ui(); }); }
    follow = true; route = null; routeKey = ''; idx = 1; said = {}; lastZ = 0; expanded = false; pvKey = '';
    setTimeout(function () { map._size(); map.render(); camera(true); }, 30);
    ui(); clearInterval(tmr); tmr = setInterval(tick, 1000); tick();
    if (voice) spk('Driving mode on');
  }
  function close() {
    if (ov) ov.classList.add('hide'); document.body.style.overflow = ''; clearInterval(tmr); tmr = null;
    if ('speechSynthesis' in window) try { speechSynthesis.cancel(); } catch (e) {}
    try { renderTrips(); } catch (e) {}
  }
  function job() { return orders.find(function (o) { return o.id === jobId; }); }

  async function fetchRoute(o) {
    var p = P(), d = dest(o); if (!p || !d || fetching) return;
    fetching = true; lastFetch = Date.now(); var my = ++rid, key = o.id + ':' + d.lat + ',' + d.lng;
    try {
      var hosts = ['https://router.project-osrm.org/route/v1/driving/', 'https://routing.openstreetmap.de/routed-car/route/v1/driving/'], j = null;
      for (var h = 0; h < hosts.length && !j; h++) {
        var ac = typeof AbortController !== 'undefined' ? new AbortController() : null, to = setTimeout(function () { if (ac) ac.abort(); }, 7000);
        try {
          var url = hosts[h] + p.lng + ',' + p.lat + ';' + d.lng + ',' + d.lat + '?overview=full&geometries=geojson&steps=true';
          var r = await fetch(url, ac ? { signal: ac.signal } : {}); var jj = await r.json();
          if (jj && jj.code === 'Ok' && jj.routes && jj.routes[0]) j = jj;
        } catch (e2) {} finally { clearTimeout(to); }
      }
      if (my !== rid) return;
      if (!j) throw new Error('no route');
      var rt = j.routes[0];
      route = { pts: rt.geometry.coordinates.map(function (c) { return [c[1], c[0]]; }), steps: rt.legs[0].steps, dist: rt.distance, dur: rt.duration };
      routeKey = key; idx = Math.min(1, route.steps.length - 1); said = {}; noRoute = false;
    } catch (e) { if (my === rid) { route = null; routeKey = key; noRoute = true; } }
    finally { fetching = false; }
  }

  function tick() {
    if (!ov || ov.classList.contains('hide')) return;
    var o = job();
    if (!o || ['out_for_delivery', 'preparing'].indexOf(o.status) < 0) {
      var l = targets(); if (!l.length) { say('All your deliveries are done. Well done!', 'ok'); return close(); }
      jobId = l[0].id; route = null; routeKey = ''; o = job();
    }
    var p = P(), d = dest(o), s = sig; ov.classList.toggle('pv', isPV(o));
    if (!follow && pauseAt && Date.now() - pauseAt > 15000) { follow = true; }
    // heading from movement
    if (p) { if (prev && SCMap.dist(prev, p) > 8) { lastH = bearing(prev, p); prev = { lat: p.lat, lng: p.lng }; } else if (!prev) prev = { lat: p.lat, lng: p.lng }; }
    // route fetch / reroute
    var key = o.id + ':' + d.lat + ',' + d.lng, near = 0, offRoute = false;
    if (p) {
      if (routeKey !== key && Date.now() - lastFetch > 4000) fetchRoute(o);
      else if (route) {
        var best = 1e9, bi = 0;
        for (var i = 0; i < route.pts.length; i++) { var q = route.pts[i], dd = SCMap.dist(p, { lat: q[0], lng: q[1] }); if (dd < best) { best = dd; bi = i; } }
        near = bi; if (best > 80 && Date.now() - lastFetch > 12000) { offRoute = true; fetchRoute(o); }
      } else if (noRoute && Date.now() - lastFetch > 20000) fetchRoute(o);
    }
    // advance steps
    var distLeft = null, durLeft = null, dm = null, st = null;
    if (route && p) {
      while (idx < route.steps.length - 1 && SCMap.dist(p, { lat: route.steps[idx].maneuver.location[1], lng: route.steps[idx].maneuver.location[0] }) < 30) idx++;
      st = route.steps[idx]; var loc = st.maneuver.location; dm = SCMap.dist(p, { lat: loc[1], lng: loc[0] });
      distLeft = dm; for (var j = idx; j < route.steps.length; j++) distLeft += route.steps[j].distance || 0;
      durLeft = route.dist > 0 ? route.dur * (distLeft / route.dist) : null;
    } else if (p) { distLeft = SCMap.dist(p, d); durLeft = distLeft * 1.35 / (20000 / 3600); }
    var arrived = p && SCMap.dist(p, d) < 70;
    draw(o, p, near, st, dm, distLeft, durLeft, arrived, offRoute);
    voiceTick(st, dm, arrived);
    camera(false, dm);
    var ns = [o.id, o.status, expanded, mini, targets().length].join('|'); if (ns !== sig) { sig = ns; sheet(o); }
    sheetLive(o, distLeft, durLeft, arrived);
  }

  function voiceTick(st, dm, arrived) {
    if (!st || !job() || job().status !== 'out_for_delivery') return;
    if (arrived) { if (!said.arr) { said.arr = 1; spk('You have arrived. Hand over the order, then slide to confirm delivery.'); } return; }
    var k = idx + '';
    if (dm < 420 && dm > 120 && !said[k + 'a']) { said[k + 'a'] = 1; spk('In ' + rndSay(dm) + ', ' + stepText(st).toLowerCase()); }
    else if (dm <= 90 && !said[k + 'b']) { said[k + 'b'] = 1; spk(stepText(st)); }
  }

  function draw(o, p, near, st, dm, distLeft, durLeft, arrived, off) {
    var top = $d('dvTop'), ar = $d('dvArrow');
    top.className = 'dv-top' + (arrived ? ' arrive' : (!p || noRoute || off) ? ' warn' : '');
    var ban = $d('dvBan'), msg = '';
    if (!p) msg = 'Finding your GPS… go outside or near a window.'; else if (o.status !== 'out_for_delivery' && !noRoute) msg = 'Route preview. Tap Start trip when you leave.'; else if (o.status !== 'out_for_delivery') msg = 'Road route unavailable. Tap Start trip, then use Google Maps.'; else if (off) msg = 'Off route. Finding a new way…'; else if (noRoute) msg = 'Road directions unavailable. Use the Google Maps button.';
    ban.textContent = msg; ban.classList.toggle('on', !!msg);
    if (arrived) { ar.innerHTML = '📍'; $d('dvDist').textContent = 'Arrived'; $d('dvText').textContent = 'Hand over the order to ' + o.customer_name; }
    else if (st) {
      var mod = (st.maneuver.modifier || 'straight'), a = ANG[mod] != null ? ANG[mod] : 0, t = st.maneuver.type;
      ar.innerHTML = t === 'arrive' ? '📍' : (t === 'roundabout' || t === 'rotary') ? '↻' : ARW; var sv = ar.querySelector('svg'); if (sv) sv.style.transform = 'rotate(' + a + 'deg)';
      $d('dvDist').textContent = rnd(dm); $d('dvText').textContent = stepText(st);
    } else if (p) { ar.innerHTML = ARW; var sv2 = ar.querySelector('svg'); if (sv2) sv2.style.transform = 'rotate(0deg)'; $d('dvDist').textContent = rnd(SCMap.dist(p, dest(o))); $d('dvText').textContent = o.status === 'out_for_delivery' ? 'Straight-line distance to ' + o.customer_name : 'Start the trip to get directions'; }
    else { ar.innerHTML = '…'; $d('dvDist').textContent = '…'; $d('dvText').textContent = 'Waiting for GPS'; }
    // map layers
    var d = dest(o), keep = { dest: 1 };
    map.setMarker('dest', d.lat, d.lng, { html: '<div class="dv-dest"><b>' + esc(o.customer_name) + '</b>' + PIN(HOME, '#111') + '</div>', anchor: 'bottom', z: 7 });
    var sp = shopPt(); if (sp) { keep.shop = 1; map.setMarker('shop', sp.lat, sp.lng, { html: PIN(STORE, '#111'), anchor: 'bottom', z: 4 }); }
    var cl = custLive(o); if (cl) { keep.cust = 1; map.setMarker('cust', cl.lat, cl.lng, { html: '<div style="font-size:30px;line-height:1;filter:drop-shadow(0 2px 3px #0008)">🧍</div>', z: 6 }); }
    if (p) { keep.me = 1; map.setMarker('me', p.lat, p.lng, { html: isPV(o) ? '<div class="dv-dot"></div>' : '<div class="dv-me" style="transform:rotate(' + Math.round(lastH == null ? 0 : lastH) + 'deg)">' + ME + '</div>', z: 9 }); }
    map.clearMarkers(keep);
    $d('dvmap').classList.toggle('night', night); $d('dvNight').textContent = night ? '☀️' : '🌙';
    $d('dvVoice').classList.toggle('on', voice); $d('dvVoice').textContent = voice ? '🔊' : '🔇';
    $d('dvRe').classList.toggle('alert', !follow);
    var live = {};
    if (route) {
      var pts = route.pts.slice(Math.max(0, near)); if (p) pts.unshift([p.lat, p.lng]);
      live.rc = 1; live.rb = 1;
      map.setLine('rc', pts, { color: '#ffffff', width: 12, opacity: 1 }); map.setLine('rb', pts, { color: '#111111', width: 7, opacity: 1 });
    } else if (p) { live.rf = 1; map.setLine('rf', [[p.lat, p.lng], [d.lat, d.lng]], { color: '#111111', width: 4, dash: '2 9' }); }
    for (var id in map.lines) if (!live[id]) map.removeLine(id);
  }

  function camera(force, dm) {
    var p = P(), oj = job(); if (!map) return;
    if (oj && isPV(oj)) {
      var k = oj.id + (route ? 'r' : 'n') + (p ? 'p' : 'x');
      if ((k !== pvKey || force) && (follow || force)) { pvKey = k; var pts = [dest(oj)]; if (p) pts.push(p); var sp = shopPt(); if (sp) pts.push(sp); map._size(); map.fit(pts, 84); follow = true; }
      return;
    }
    if (!p) return;
    if (!follow && !force) return;
    var z = dm != null && dm < 350 ? 18 : dm != null && dm < 1500 ? 17 : 16;
    map._size(); if (z !== lastZ || force) { lastZ = z; map.setView(p.lat, p.lng, z); } else map.setView(p.lat, p.lng, null);
    follow = true; // setView does not count as a manual move
  }

  function ui() {
    if (!ov) return;
    $d('dvmap').classList.toggle('night', night); $d('dvNight').textContent = night ? '☀️' : '🌙';
    $d('dvVoice').classList.toggle('on', voice); $d('dvVoice').textContent = voice ? '🔊' : '🔇'; $d('dvRe').classList.toggle('alert', !follow);
  }

  function sheet(o) {
    var sh = $d('dvSheet'), list = targets(), cash = o.payment_method === 'cod' && o.payment_status !== 'paid';
    var chips = list.length > 1 ? '<div class="dv-chips">' + list.map(function (x) { return '<button class="' + (x.id === o.id ? 'on' : '') + '" onclick="Drive.pick(\'' + x.id + '\')">' + esc(short(x)) + ' · ' + esc(String(x.customer_name).split(' ')[0]) + '</button>'; }).join('') + '</div>' : '';
    var wa = 'Hello ' + o.customer_name + ', I am your SweetCraft delivery driver for order ' + o.order_no + '. I am on my way.';
    var more = expanded ? '<div class="dv-more"><div><b>Address</b><br>' + esc(o.address || '') + '</div>' + (o.notes ? '<div><b>Customer note</b><br>' + esc(o.notes) + '</div>' : '') + '<div><b>Order</b><br>' + itemsHtml(o) + '</div><div>' + payLine(o) + ' · <b>' + etb(o.total) + '</b></div>' + (typeof locInfo === 'function' ? locInfo(o) : '') + '</div>' : '';
    var act = o.status === 'out_for_delivery' ? '<div class="dv-slide" id="dvSlide"><span>Slide when delivered</span><i>➜</i></div>' : '<div class="dv-slide" id="dvSlide" style="background:#1f5fbf"><span>Slide to start the trip</span><i style="color:#1f5fbf">➜</i></div>';
    if (isPV(o)) {
      var n = nItems(o), pr = P(), straight = pr ? SCMap.dist(pr, dest(o)) : null, dd = route ? route.dist : (straight != null ? straight * 1.3 : null), mm = route ? Math.max(1, Math.round(route.dur / 60)) : (dd != null ? Math.max(1, Math.round(dd / 1000 / 20 * 60)) : null);
      var meta = (n ? n + (n === 1 ? ' item' : ' items') + ' · ' : '') + (dd != null ? fmtDist(dd) + (mm ? ' · ~' + mm + ' min' : '') : 'Finding your GPS…');
      var pay = cash ? '<div class="dv-pay cash"><b>' + etb(o.total) + '</b><small>Collect cash from the customer</small></div>' : '<div class="dv-pay"><b>Paid</b><small>Nothing to collect · ' + etb(o.total) + '</small></div>';
      var more2 = expanded ? '<div class="dv-more"><div><b>Order</b><br>' + itemsHtml(o) + '</div>' + (o.notes ? '<div><b>Customer note</b><br>' + esc(o.notes) + '</div>' : '') + (typeof locInfo === 'function' ? locInfo(o) : '') + '</div>' : '';
      sh.className = 'dv-sheet offer'; sh.innerHTML = chips +
        '<div class="dv-by">Deliver to</div><div class="dv-name">' + esc(o.customer_name) + '</div><div class="dv-meta" id="dvMeta">' + esc(meta) + '</div>' +
        '<div class="dv-line"></div>' + pay + '<div class="dv-addr">📍 ' + esc(o.address || 'Pin on the map') + '</div>' +
        '<div class="dv-row"><a class="dv-btn" href="tel:' + esc(o.phone) + '">📞 Call</a><a class="dv-btn" href="' + navUrl(o) + '" target="_blank" rel="noopener">🧭 Google Maps</a><button class="dv-btn" onclick="Drive.more()">' + (expanded ? '▾ Less' : '▴ Details') + '</button></div>' + more2 +
        '<button class="dv-go" id="dvGo">Start trip</button>';
      $d('dvGo').onclick = function () { doAction(o.id); };
      return;
    }
    sh.className = 'dv-sheet' + (mini ? ' min' : ''); sh.innerHTML = '<div class="dv-grab" onclick="Drive.mini()"></div>' + chips + '<div class="dv-eta"><b id="dvEta">–</b><span id="dvSub"></span></div>' +
      '<div class="dv-cust"><div class="av">' + esc(initials(o.customer_name)) + '</div><div><b>' + esc(o.customer_name) + '</b><small>' + esc(o.address || '') + '</small></div></div>' +
      (cash ? '<div class="dv-cash">💵 Collect ' + etb(o.total) + ' cash</div>' : '') +
      '<div class="dv-row"><a class="dv-btn" href="tel:' + esc(o.phone) + '">📞 Call</a><a class="dv-btn pri" href="' + navUrl(o) + '" target="_blank" rel="noopener">🧭 Google Maps</a><button class="dv-btn" onclick="Drive.more()">' + (expanded ? '▾ Less' : '▴ Details') + '</button></div>' + act + more +
      '<div class="dv-hint">Park safely before using your phone.</div>';
    var sl = $d('dvSlide'); if (sl) slider(sl, function () { doAction(o.id); });
  }
  function sheetLive(o, dl, du, arrived) {
    var mt = $d('dvMeta'); if (mt && isPV(o)) { var n2 = nItems(o), mm2 = du != null ? Math.max(1, Math.round(du / 60)) : null; if (dl != null) mt.textContent = (n2 ? n2 + (n2 === 1 ? ' item' : ' items') + ' · ' : '') + fmtDist(route ? route.dist : dl * 1.3) + (route ? ' · ~' + Math.max(1, Math.round(route.dur / 60)) + ' min' : ''); }
    var e = $d('dvEta'); if (!e) return;
    if (dl == null) { e.textContent = '–'; $d('dvSub').textContent = 'Waiting for GPS'; return; }
    var min = Math.max(1, Math.round((du || 0) / 60)), at = new Date(Date.now() + min * 60000);
    e.textContent = arrived ? 'Here' : min + ' min';
    $d('dvSub').textContent = fmtDist(dl) + (arrived ? ' · you have arrived' : ' · arrive ' + at.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }));
    var sl = $d('dvSlide'); if (sl) sl.classList.toggle('arrived', !!arrived && o.status === 'out_for_delivery');
  }
  function slider(el, done) {
    var th = el.querySelector('i'), sx = 0, x = 0, max = 0, on = false;
    th.addEventListener('pointerdown', function (e) { on = true; sx = e.clientX; max = el.clientWidth - th.clientWidth - 10; th.setPointerCapture(e.pointerId); });
    th.addEventListener('pointermove', function (e) { if (!on) return; x = Math.max(0, Math.min(max, e.clientX - sx)); th.style.transform = 'translateX(' + x + 'px)'; });
    var end = function () { if (!on) return; on = false; if (x > max * 0.88) { th.style.transform = 'translateX(' + max + 'px)'; done(); } else { x = 0; th.style.transform = ''; } };
    th.addEventListener('pointerup', end); th.addEventListener('pointercancel', end);
  }
  async function doAction(id) {
    var o = orders.find(function (x) { return x.id === id; }); if (!o) return;
    if (o.status === 'out_for_delivery') { var ok = await trip(id, 'delivered'); if (ok) { spk('Delivered. Thank you.'); sig = ''; tick(); } else { sig = ''; flash(); } }
    else { var ok2 = await trip(id, 'out_for_delivery'); route = null; routeKey = ''; sig = ''; if (ok2) spk('Trip started'); else flash(); tick(); }
  }

  function flash() {
    var m = document.getElementById('msg'), t = m ? m.textContent : '', b = $d('dvBan'); if (!b || !t) return;
    b.textContent = t; b.classList.add('on'); setTimeout(function () { b.classList.remove('on'); }, 5000);
  }
  function fab() {
    var b = document.getElementById('driveFab');
    var any = me && typeof tab !== 'undefined' && tab === 'trips' && orders.some(function (o) { return isDel(o) && o.driver_id === me.id && o.status === 'out_for_delivery' && dest(o); });
    if (!any || (ov && !ov.classList.contains('hide'))) { if (b) b.remove(); return; }
    if (!b) { b = document.createElement('button'); b.id = 'driveFab'; b.onclick = function () { open(); }; document.body.appendChild(b); }
    b.textContent = '🚗  Open driving mode';
  }
  window.Drive = {
    open: open, close: close, fab: fab,
    pick: function (id) { jobId = id; pvKey = ''; route = null; routeKey = ''; idx = 1; said = {}; sig = ''; follow = true; tick(); },
    mini: function () { mini = !mini; sig = ''; tick(); setTimeout(function () { map._size(); map.render(); }, 30); },
    more: function () { expanded = !expanded; sig = ''; tick(); setTimeout(function () { map._size(); map.render(); }, 30); }
  };
  try { fab(); } catch (e) {}
  // keep the floating button in step with the trips list
  var _rt = window.renderTrips; if (typeof _rt === 'function') window.renderTrips = function () { var r = _rt.apply(this, arguments); try { fab(); } catch (e) {} return r; };
})();
