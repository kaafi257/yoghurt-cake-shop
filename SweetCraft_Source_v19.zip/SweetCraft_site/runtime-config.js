window.SWEETCRAFT_SUPABASE = {"url":"https://ucyicnxykdvxbbgokxcq.supabase.co","key":"sb_publishable_0cw1I4TINn_CkH9yhbF53g_10e8vfV6"};
