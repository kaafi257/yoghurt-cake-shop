/* Keeps the stand-alone pages (shop, orders, reports, salary, qr) on the newest version.
   If a newer build is live, it drops any old offline copy and reloads once. */
(function () {
  var K = 'sc_build_seen', busy = false;
  async function check() {
    if (busy) return; busy = true;
    try {
      var r = await fetch('/version.json?t=' + Date.now(), { cache: 'no-store' });
      if (!r.ok) return;
      var j = await r.json();
      if (!j || !j.id) return;
      var seen = null; try { seen = localStorage.getItem(K); } catch (e) {}
      if (seen === j.id) return;
      try { localStorage.setItem(K, j.id); } catch (e) {}
      var regs = (navigator.serviceWorker && navigator.serviceWorker.getRegistrations) ? await navigator.serviceWorker.getRegistrations() : [];
      var keys = ('caches' in window) ? await caches.keys() : [];
      await Promise.all(regs.map(function (g) { return g.unregister(); }));
      await Promise.all(keys.map(function (k) { return caches.delete(k); }));
      if (regs.length || keys.length || seen !== null) location.reload();
    } catch (e) { /* offline: try again later */ }
    finally { busy = false; }
  }
  check();
  document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'visible') check(); });
  setInterval(check, 5 * 60 * 1000);
})();
