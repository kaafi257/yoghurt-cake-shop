/* SweetCraft profile pictures for the main + employee app.
   Attaches to the page without touching the app bundle. Safe: if anything fails, initials stay. */
(function () {
  'use strict';
  var URL_ = 'https://ucyicnxykdvxbbgokxcq.supabase.co';
  var KEY = 'sb_publishable_0cw1I4TINn_CkH9yhbF53g_10e8vfV6';
  var SKEY = 'sb-ucyicnxykdvxbbgokxcq-auth-token';
  var me = null, byId = {}, byName = {}, loadedFor = null, loading = false, msgEl = null;

  function session() {
    try { var s = JSON.parse(localStorage.getItem(SKEY) || 'null'); return s && s.access_token ? (s.currentSession || s) : null; } catch (e) { return null; }
  }
  function hdr(s, extra) {
    var h = { apikey: KEY, Authorization: 'Bearer ' + s.access_token };
    for (var k in extra) h[k] = extra[k];
    return h;
  }
  function get(path, s) {
    return fetch(URL_ + path, { headers: hdr(s, {}) }).then(function (r) { if (!r.ok) throw new Error(r.status); return r.json(); });
  }
  function load() {
    var s = session();
    if (!s || !s.user || loading || loadedFor === s.user.id) return;
    loading = true;
    get('/rest/v1/profiles?select=id,full_name,avatar_url', s).then(function (rows) {
      me = s.user.id; byId = {}; byName = {};
      rows.forEach(function (r) { if (r.avatar_url) { byId[r.id] = r.avatar_url; if (r.full_name) byName[r.full_name.trim()] = r.avatar_url; } });
      loadedFor = s.user.id; apply();
    }).catch(function () { loadedFor = s.user.id; /* column not added yet: keep initials */ })
      .then(function () { loading = false; apply(); });
  }

  function paint(el, url, label) {
    if (!url) { if (el.dataset.pp) { el.dataset.pp = ''; var t = el.dataset.ppText; el.textContent = t || ''; } return; }
    if (el.dataset.pp === url) return;
    if (!el.dataset.pp) el.dataset.ppText = el.textContent;
    el.dataset.pp = url;
    el.style.overflow = 'hidden'; el.style.padding = '0';
    var img = new Image(); img.alt = label || ''; img.src = url;
    img.style.cssText = 'width:100%;height:100%;object-fit:cover;display:block';
    img.onerror = function () { el.dataset.pp = ''; el.textContent = el.dataset.ppText || ''; };
    el.textContent = ''; el.appendChild(img);
  }

  function addCamera(av) {
    if (av.dataset.ppCam) return; av.dataset.ppCam = '1';
    av.style.position = 'relative'; av.style.overflow = 'visible';
    var lab = document.createElement('label');
    lab.title = 'Change profile photo'; lab.setAttribute('aria-label', 'Change profile photo');
    lab.style.cssText = 'position:absolute;right:-6px;bottom:-6px;width:24px;height:24px;border-radius:50%;background:#4A2530;color:#fff;display:grid;place-items:center;cursor:pointer;border:2px solid #E39A88;font-size:12px;z-index:2';
    lab.textContent = '📷';
    var inp = document.createElement('input'); inp.type = 'file'; inp.accept = 'image/*'; inp.hidden = true; inp.setAttribute('data-testid', 'avatar-input');
    inp.onchange = function () { var f = inp.files && inp.files[0]; inp.value = ''; if (f) change(f); };
    lab.appendChild(inp); av.appendChild(lab);
    var who = av.nextElementSibling;
    if (who) { msgEl = document.createElement('span'); msgEl.style.cssText = 'display:block;font-size:11px;opacity:.85'; who.appendChild(msgEl); }
  }
  function say(t, remove) {
    if (!msgEl) return; msgEl.textContent = t || '';
    if (remove && byId[me]) {
      var b = document.createElement('button'); b.type = 'button'; b.textContent = 'Remove photo';
      b.style.cssText = 'background:none;border:0;padding:0;color:inherit;opacity:.75;font-size:11px;text-decoration:underline;cursor:pointer';
      b.onclick = removePhoto; msgEl.appendChild(b);
    }
  }

  function apply() {
    var mine = byId[me] || '';
    var chip = document.querySelector('.user-chip .user-avatar');
    if (chip) paint(chip, mine, 'You');
    var dr = document.querySelector('.drawer-avatar');
    if (dr) {
      var cam = dr.querySelector('label');
      paintKeep(dr, mine);
      addCamera(dr);
      if (msgEl && !msgEl.textContent && mine) say('', true);
    } else { msgEl = null; }
    // "Staff today" rows: match by the visible name
    document.querySelectorAll('.user-avatar').forEach(function (el) {
      if (el === chip || el.closest('.user-chip')) return;
      var strong = el.parentElement && el.parentElement.querySelector('strong');
      var n = strong && strong.textContent.trim();
      if (n && byName[n]) paint(el, byName[n], n);
    });
  }
  // drawer avatar contains the camera label, so only swap its first text/img node
  function paintKeep(dr, url) {
    var holder = dr.querySelector('[data-pp-holder]');
    if (!holder) {
      holder = document.createElement('span'); holder.setAttribute('data-pp-holder', '1');
      holder.style.cssText = 'display:grid;place-items:center;width:100%;height:100%;border-radius:inherit;overflow:hidden';
      holder.textContent = Array.prototype.filter.call(dr.childNodes, function (n) { return n.nodeType === 3; }).map(function (n) { return n.nodeValue; }).join('');
      Array.prototype.slice.call(dr.childNodes).forEach(function (n) { if (n.nodeType === 3) dr.removeChild(n); });
      dr.insertBefore(holder, dr.firstChild);
    }
    if (url) {
      if (holder.dataset.pp !== url) {
        holder.dataset.pp = url; var txt = holder.dataset.t || holder.textContent; holder.dataset.t = txt;
        holder.textContent = ''; var img = new Image(); img.src = url; img.alt = '';
        img.style.cssText = 'width:100%;height:100%;object-fit:cover;display:block';
        img.onerror = function () { holder.dataset.pp = ''; holder.textContent = txt; };
        holder.appendChild(img);
      }
    } else if (holder.dataset.pp) { holder.dataset.pp = ''; holder.textContent = holder.dataset.t || ''; }
  }

  function shrink(file) {
    return new Promise(function (ok, bad) {
      if (!/^image\//.test(file.type)) return bad(new Error('Choose a photo (JPG or PNG).'));
      if (file.size > 10 * 1024 * 1024) return bad(new Error('Photo is too large (max 10 MB).'));
      var img = new Image(), u = URL.createObjectURL(file);
      img.onload = function () {
        var side = Math.min(img.width, img.height), c = document.createElement('canvas'); c.width = c.height = 320;
        var x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, 320, 320);
        x.drawImage(img, (img.width - side) / 2, (img.height - side) / 2, side, side, 0, 0, 320, 320);
        URL.revokeObjectURL(u); c.toBlob(function (b) { b ? ok(b) : bad(new Error('Could not process the photo.')); }, 'image/jpeg', 0.85);
      };
      img.onerror = function () { URL.revokeObjectURL(u); bad(new Error('That photo could not be read.')); };
      img.src = u;
    });
  }
  function rpc(name, args, s) {
    return fetch(URL_ + '/rest/v1/rpc/' + name, { method: 'POST', headers: hdr(s, { 'Content-Type': 'application/json' }), body: JSON.stringify(args) })
      .then(function (r) { if (!r.ok) throw new Error('save'); });
  }
  function change(file) {
    var s = session(); if (!s) return;
    say('Saving photo…');
    shrink(file).then(function (blob) {
      var path = s.user.id + '/avatar.jpg';
      return fetch(URL_ + '/storage/v1/object/avatars/' + path, { method: 'POST', headers: hdr(s, { 'Content-Type': 'image/jpeg', 'x-upsert': 'true', 'cache-control': 'max-age=3600' }), body: blob })
        .then(function (r) { if (!r.ok) throw new Error('Could not upload. Run the profile-pictures SQL in Supabase first.'); })
        .then(function () { var url = URL_ + '/storage/v1/object/public/avatars/' + path + '?v=' + Date.now(); return rpc('set_my_avatar', { p_url: url }, s).then(function () { return url; }); });
    }).then(function (url) { byId[me] = url; apply(); say('', true); })
      .catch(function (e) { say(e.message || 'Could not save the photo.'); });
  }
  function removePhoto() {
    var s = session(); if (!s) return; say('Removing…');
    rpc('set_my_avatar', { p_url: null }, s).then(function () { delete byId[me]; apply(); say(''); }).catch(function () { say('Could not remove the photo.'); });
  }

  var t = null;
  new MutationObserver(function () { clearTimeout(t); t = setTimeout(function () { load(); apply(); }, 60); }).observe(document.documentElement, { childList: true, subtree: true });
  window.addEventListener('storage', function () { loadedFor = null; load(); });
  load();
})();
