// Public Supabase settings (same project as the main SweetCraft app).
// The publishable key is safe in the browser. NEVER put a service_role key here.
export const SUPABASE_URL = 'https://ucyicnxykdvxbbgokxcq.supabase.co';
export const SUPABASE_KEY = 'sb_publishable_0cw1I4TINn_CkH9yhbF53g_10e8vfV6';
// Reports is a standalone app: its own session and its own theme.
export const STORAGE_KEY = 'sweetcraft-reports-auth'; // own login, independent of the main app
export const THEME_KEY = 'sweetcraft_reports_theme'; // own theme, independent of the main app
export const TZ = 'Africa/Addis_Ababa';
export const TZ_OFFSET_MS = 3 * 3600 * 1000; // UTC+3, no daylight saving
// UI gate only. Real enforcement is Supabase RLS (see sql/README).
export const ALLOWED_ROLES = ['owner', 'reports']; // 'reports' = view-only login created by the owner (Staff > Add staff)
export const PAGE_SIZE = 1000;
export const MAX_ROWS = 50000;
