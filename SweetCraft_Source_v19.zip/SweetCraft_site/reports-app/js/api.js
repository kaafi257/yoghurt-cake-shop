// Minimal Supabase client (Auth + PostgREST) using only fetch.
// Every request carries the signed-in user's JWT, so Row Level Security decides what is returned.
import { SUPABASE_URL, SUPABASE_KEY, STORAGE_KEY, PAGE_SIZE, MAX_ROWS } from './config.js';

const readStore = () => { try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null'); } catch { return null; } };
const writeStore = (s) => { try { localStorage.setItem(STORAGE_KEY, JSON.stringify(s)); } catch { /* private mode */ } };

let session = readStore();
let refreshing = null;

// Never wait forever on a slow network.
const fetchT = (url, init = {}, ms = 20000) => {
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), ms);
  return fetch(url, { ...init, signal: ctl.signal })
    .catch((e) => { throw e && e.name === 'AbortError' ? new Error('The connection is too slow. Try again.') : e; })
    .finally(() => clearTimeout(t));
};

const nowSec = () => Math.floor(Date.now() / 1000);

function normalise(body) {
  const s = { ...body };
  if (!s.expires_at && s.expires_in) s.expires_at = nowSec() + Number(s.expires_in);
  return s;
}

async function authFetch(path, body) {
  const res = await fetchT(`${SUPABASE_URL}/auth/v1/${path}`, {
    method: 'POST',
    headers: { apikey: SUPABASE_KEY, 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) {
    const err = new Error(json.error_description || json.msg || json.message || 'Authentication failed');
    err.status = res.status;
    throw err;
  }
  return json;
}

async function refresh() {
  if (!session?.refresh_token) throw new Error('Not signed in');
  if (!refreshing) {
    refreshing = authFetch('token?grant_type=refresh_token', { refresh_token: session.refresh_token })
      .then((j) => { session = normalise(j); writeStore(session); return session; })
      .finally(() => { refreshing = null; });
  }
  return refreshing;
}

export function hasSession() { return !!(session && (session.access_token || session.refresh_token)); }

export async function signIn(email, password) {
  const j = await authFetch('token?grant_type=password', { email, password });
  session = normalise(j);
  writeStore(session);
  return session;
}

export function signOut() { session = null; try { localStorage.removeItem(STORAGE_KEY); } catch { /* ignore */ } }

export const currentUserId = () => session?.user?.id || null;

async function token() {
  if (!session) throw new Error('Not signed in');
  if (!session.expires_at || session.expires_at - nowSec() < 60) {
    try { await refresh(); } catch (e) { if (!session.access_token) throw e; }
  }
  return session.access_token;
}

export class ApiError extends Error {
  constructor(message, { status, code } = {}) { super(message); this.status = status; this.code = code; }
}

async function call(path, init = {}, retry = true) {
  const t = await token();
  const res = await fetchT(`${SUPABASE_URL}${path}`, {
    ...init,
    headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${t}`, 'Content-Type': 'application/json', ...(init.headers || {}) },
  });
  if (res.status === 401 && retry) {
    try { await refresh(); return call(path, init, false); } catch { /* fall through */ }
  }
  const text = await res.text();
  let json = null;
  try { json = text ? JSON.parse(text) : null; } catch { /* not json */ }
  if (!res.ok) {
    throw new ApiError(json?.message || json?.error_description || `Request failed (${res.status})`, { status: res.status, code: json?.code });
  }
  return json;
}

/** True when the table/function simply does not exist yet (migration not run). */
export const isMissing = (e) => e && (e.code === '42P01' || e.code === 'PGRST205' || e.code === 'PGRST202' || e.status === 404);

/** Fetch every page of a table query. `filters` is an array of [column, 'op.value'] pairs. */
export async function fetchAll(table, { select, filters = [], order }) {
  const rows = [];
  for (let offset = 0; offset < MAX_ROWS; offset += PAGE_SIZE) {
    const q = new URLSearchParams();
    q.set('select', select);
    for (const [k, v] of filters) q.append(k, v);
    if (order) q.set('order', order);
    q.set('limit', String(PAGE_SIZE));
    q.set('offset', String(offset));
    const page = await call(`/rest/v1/${table}?${q}`);
    rows.push(...page);
    if (page.length < PAGE_SIZE) break;
  }
  return rows;
}

export const rpc = (name, args = {}) => call(`/rest/v1/rpc/${name}`, { method: 'POST', body: JSON.stringify(args) });

/** Profile picture: upload a small JPEG to the `avatars` bucket (own folder) and save its link on the profile. */
export async function uploadAvatar(blob) {
  const uid = currentUserId();
  if (!uid) throw new Error('Not signed in');
  const t = await token();
  const path = `${uid}/avatar.jpg`;
  const res = await fetchT(`${SUPABASE_URL}/storage/v1/object/avatars/${path}`, {
    method: 'POST',
    headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${t}`, 'Content-Type': 'image/jpeg', 'x-upsert': 'true', 'cache-control': 'max-age=3600' },
    body: blob,
  }, 40000);
  if (!res.ok) throw new Error('Could not upload the photo. Ask the owner to run the Fix_All SQL in Supabase.');
  const url = `${SUPABASE_URL}/storage/v1/object/public/avatars/${path}?v=${Date.now()}`;
  await rpc('set_my_avatar', { p_url: url });
  return url;
}

export async function removeAvatar() {
  await rpc('set_my_avatar', { p_url: null });
}
