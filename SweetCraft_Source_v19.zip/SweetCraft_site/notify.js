/* SweetCraft notification bell. One file, used by every page.
   SCNotify.mount(element | null, rpc) -> stop()
   rpc(name, args) must return the function's data (or throw). With element=null the bell floats top-right. */
(function(){
  if(window.SCNotify)return;
  var css=''
  +'.scn{--n-bg:#FFFDF9;--n-ink:#33191f;--n-mut:#7f6a70;--n-line:#E8DDCB;--n-hi:#F3EADB;--n-acc:#6B1D2F;--n-gold:#B8923A;position:relative;display:inline-block;font:14px/1.4 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;z-index:60}'
  +'[data-theme=dark] .scn,.dark .scn{--n-bg:#241218;--n-ink:#f3e6e9;--n-mut:#a58f95;--n-line:#3a2229;--n-hi:#2f1920;--n-acc:#e9b7c3;--n-gold:#d9b45e}'
  +'.scn.float{position:fixed;top:calc(10px + env(safe-area-inset-top,0px));right:12px}'
  +'.scn-b{position:relative;width:40px;height:40px;border-radius:50%;border:1px solid var(--n-line);background:var(--n-bg);color:var(--n-acc);display:grid;place-items:center;padding:0;cursor:pointer;box-shadow:0 2px 10px #0002}'
  +'.scn-b:hover{background:var(--n-hi)}.scn-b svg{width:20px;height:20px}'
  +'.scn-b em{position:absolute;top:-4px;right:-4px;min-width:19px;height:19px;padding:0 5px;border-radius:99px;background:#c0392b;color:#fff;font:700 11px/19px system-ui;font-style:normal;text-align:center;border:2px solid var(--n-bg);box-sizing:content-box}'
  +'.scn-b.ring svg{animation:scnr .7s ease 1}@keyframes scnr{20%{transform:rotate(14deg)}40%{transform:rotate(-12deg)}60%{transform:rotate(8deg)}80%{transform:rotate(-4deg)}}'
  +'.scn-p{position:absolute;right:0;top:48px;width:min(380px,calc(100vw - 24px));max-height:min(70vh,560px);display:none;flex-direction:column;background:var(--n-bg);color:var(--n-ink);border:1px solid var(--n-line);border-radius:18px;box-shadow:0 18px 50px #0004;overflow:hidden}'
  +'.scn.open .scn-p{display:flex}'
  +'.scn-h{display:flex;align-items:center;gap:8px;padding:14px 16px 10px}.scn .scn-h b{font:700 18px Georgia,serif;flex:1;display:block;letter-spacing:normal;text-transform:none;color:var(--n-ink)}'
  +'.scn-h button{border:0;background:none;color:var(--n-acc);font:600 13px system-ui;cursor:pointer;padding:6px 8px;border-radius:8px}.scn-h button:hover{background:var(--n-hi)}.scn-h button:disabled{opacity:.4;cursor:default}'
  +'.scn-l{overflow:auto;overscroll-behavior:contain;border-top:1px solid var(--n-line)}'
  +'.scn-i{display:flex;gap:11px;width:100%;text-align:left;border:0;border-bottom:1px solid var(--n-line);background:none;color:inherit;padding:12px 16px;cursor:pointer;font:inherit}'
  +'.scn-i:hover{background:var(--n-hi)}.scn-i:last-child{border-bottom:0}'
  +'.scn-i.un{background:color-mix(in srgb,var(--n-gold) 11%,transparent)}'
  +'.scn-ic{flex:none;width:34px;height:34px;border-radius:50%;display:grid;place-items:center;background:var(--n-hi);color:var(--n-acc);font-size:16px}'
  +'.scn-t{flex:1;min-width:0}.scn .scn-t b{display:block;font:650 14px/1.4 system-ui,-apple-system,sans-serif;letter-spacing:normal;color:var(--n-ink)}.scn .scn-t span{display:block;color:var(--n-mut);font-size:13px;overflow-wrap:anywhere}.scn .scn-t small{display:inline;color:var(--n-mut);font-size:12px;letter-spacing:normal;text-transform:none}'
  +'.scn .scn-i.un .scn-t b::after{content:"";display:inline-block;width:8px;height:8px;border-radius:50%;background:var(--n-gold);margin-left:7px}'
  +'.scn-e{padding:34px 16px;text-align:center;color:var(--n-mut)}'
  +'.scn-toast{position:fixed;left:50%;top:calc(12px + env(safe-area-inset-top,0px));transform:translate(-50%,-70px);max-width:min(420px,calc(100vw - 24px));background:var(--n-bg,#FFFDF9);color:var(--n-ink,#33191f);border:1px solid var(--n-gold,#B8923A);border-radius:14px;padding:10px 14px;box-shadow:0 12px 36px #0004;z-index:90;transition:transform .35s cubic-bezier(.22,1,.36,1);font:14px system-ui}'
  +'.scn-toast.on{transform:translate(-50%,0)}'
  +'@media(max-width:560px){.scn-p{position:fixed;left:8px;right:8px;top:calc(60px + env(safe-area-inset-top,0px));width:auto}}'
  +'@media(prefers-reduced-motion:reduce){.scn-b.ring svg,.scn-toast{animation:none;transition:none}}';
  var ICON={sale:'🧁',expense:'🧾',order:'🛍️',payment:'💳',salary:'💰',void:'↩️'};
  function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
  function ago(t){var s=Math.max(0,(Date.now()-new Date(t))/1000);if(s<60)return'just now';if(s<3600)return Math.floor(s/60)+' min ago';if(s<86400)return Math.floor(s/3600)+' h ago';
    return new Date(t).toLocaleDateString('en-US',{day:'numeric',month:'short'})}
  function mount(el,rpc){
    if(!document.getElementById('scn-css')){var st=document.createElement('style');st.id='scn-css';st.textContent=css;document.head.appendChild(st)}
    var root=document.createElement('div');root.className='scn'+(el?'':' float');
    root.innerHTML='<button class="scn-b" type="button" aria-label="Notifications" aria-haspopup="true" aria-expanded="false"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 8a6 6 0 0112 0c0 7 3 8 3 8H3s3-1 3-8"/><path d="M10.3 21a1.9 1.9 0 003.4 0"/></svg></button>'
     +'<div class="scn-p" role="dialog" aria-label="Notifications"><div class="scn-h"><b>Notifications</b><button type="button" data-all>Mark all read</button></div><div class="scn-l"></div></div>';
    (el||document.body).appendChild(root);
    var btn=root.querySelector('.scn-b'),list=root.querySelector('.scn-l'),all=root.querySelector('[data-all]'),items=[],unread=0,seen=null,timer=null,busy=false,dead=false;
    function badge(){var e=btn.querySelector('em');if(unread>0){if(!e){e=document.createElement('em');btn.appendChild(e)}e.textContent=unread>99?'99+':unread}else if(e)e.remove();all.disabled=unread===0;btn.setAttribute('aria-label','Notifications'+(unread?', '+unread+' unread':''))}
    function draw(){
      list.innerHTML=items.length?items.map(function(n){return'<button class="scn-i'+(n.read?'':' un')+'" type="button" data-id="'+n.id+'" data-link="'+esc(n.link||'')+'"><div class="scn-ic" aria-hidden="true">'+(ICON[n.kind]||'🔔')+'</div><div class="scn-t"><b>'+esc(n.title)+'</b>'+(n.body?'<span>'+esc(n.body)+'</span>':'')+'<small>'+ago(n.created_at)+'</small></div></button>'}).join(''):'<div class="scn-e">You are all caught up.<br>New sales, orders and payments show here.</div>';badge()}
    function toast(n){var t=document.createElement('div');t.className='scn-toast';t.setAttribute('role','status');t.innerHTML='<b>'+esc(n.title)+'</b>'+(n.body?'<br>'+esc(n.body):'');document.body.appendChild(t);
      requestAnimationFrame(function(){t.classList.add('on')});setTimeout(function(){t.classList.remove('on');setTimeout(function(){t.remove()},400)},4200)}
    async function load(){
      if(busy||dead)return;busy=true;
      try{var d=await rpc('notifications_list',{p_limit:40});if(dead||!d)return;items=d.items||[];unread=d.unread||0;
        var top=items.length?Number(items[0].id):0;
        if(seen!==null&&top>seen){var fresh=items.filter(function(n){return Number(n.id)>seen&&!n.read});if(fresh.length){toast(fresh[0]);btn.classList.remove('ring');void btn.offsetWidth;btn.classList.add('ring')}}
        seen=Math.max(seen||0,top);draw()}
      catch(e){/* not set up yet or signed out: stay quiet */}
      finally{busy=false}}
    function toggle(open){root.classList.toggle('open',open);btn.setAttribute('aria-expanded',open);if(open){load();list.scrollTop=0}}
    btn.onclick=function(e){e.stopPropagation();toggle(!root.classList.contains('open'))};
    all.onclick=async function(){items.forEach(function(n){n.read=true});unread=0;draw();try{await rpc('notifications_mark_all_read',{})}catch(e){load()}};
    list.onclick=async function(e){var b=e.target.closest('.scn-i');if(!b)return;var id=Number(b.dataset.id),link=b.dataset.link;
      var n=items.find(function(x){return Number(x.id)===id});if(n&&!n.read){n.read=true;unread=Math.max(0,unread-1);draw();try{await rpc('notification_mark_read',{p_id:id})}catch(e){}}
      if(link&&link!==location.pathname){location.href=link}else toggle(false)};
    function outside(e){if(!root.contains(e.target))toggle(false)}
    function key(e){if(e.key==='Escape'&&root.classList.contains('open')){toggle(false);btn.focus()}}
    function vis(){if(!document.hidden)load()}
    document.addEventListener('click',outside);document.addEventListener('keydown',key);document.addEventListener('visibilitychange',vis);
    load();timer=setInterval(function(){if(!document.hidden)load()},30000);
    return function stop(){dead=true;clearInterval(timer);document.removeEventListener('click',outside);document.removeEventListener('keydown',key);document.removeEventListener('visibilitychange',vis);root.remove()};
  }
  window.SCNotify={mount:mount};

  /* ---- automatic mode: loading this file on a page is enough. It finds the signed-in session itself,
     sits beside the top-bar buttons, and removes itself on sign-out. Pages that mount their own bell
     load it with data-manual and are skipped. ---- */
  var me=document.currentScript;
  if(me&&me.hasAttribute('data-manual'))return;
  var URL_='https://ucyicnxykdvxbbgokxcq.supabase.co',KEY='sb_publishable_0cw1I4TINn_CkH9yhbF53g_10e8vfV6',SK='sb-ucyicnxykdvxbbgokxcq-auth-token';
  function token(){try{var v=JSON.parse(localStorage.getItem(SK)||'null');return v&&(v.access_token||(v.currentSession&&v.currentSession.access_token))||null}catch(e){return null}}
  function rest(n,a){var t=token();if(!t)return Promise.reject(new Error('no session'));
    return fetch(URL_+'/rest/v1/rpc/'+n,{method:'POST',headers:{apikey:KEY,Authorization:'Bearer '+t,'Content-Type':'application/json'},body:JSON.stringify(a||{})})
      .then(function(r){if(!r.ok)throw new Error(String(r.status));return r.text()}).then(function(x){return x?JSON.parse(x):null})}
  var stop=null,host=null;
  function place(){
    if(!host)return;var phone=innerWidth<=768,ref=document.querySelector(phone?'.mobile-app-header .header-theme-btn':'.topbar-right .user-chip'),r=ref&&ref.getBoundingClientRect();
    if(r&&r.width){host.style.top=(r.top+(r.height-40)/2)+'px';host.style.right=(innerWidth-r.left+8)+'px'}
    else{host.style.top='calc(10px + env(safe-area-inset-top,0px))';host.style.right='12px'}}
  function tick(){
    var t=token();
    if(t&&!stop&&!document.querySelector('.scn')){stop=mount(null,rest);host=document.querySelector('.scn.float');place()}
    else if(!t&&stop){stop();stop=null;host=null}
    place()}
  setInterval(tick,1500);addEventListener('resize',place);tick();
})();
