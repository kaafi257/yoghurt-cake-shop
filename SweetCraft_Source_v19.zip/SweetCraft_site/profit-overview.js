/* SweetCraft Profit Overview: replaces the Net profit ring on the owner/manager Dashboard. */
(function(){'use strict';
const CSS_TEXT = "/* Profit Overview card (Dashboard, owner/manager) */\n.po{--po-ink:#6B2437;--po-soft:#8A5A66;--po-bg:linear-gradient(180deg,#FFFDF9,#FBF5EC);--po-bd:#EADCCB;--po-chip:#F3E8DA;--po-chip-bd:#E8D9C6;--po-field:#FFFCF7;--po-grid:#EBDDCB;--po-line:#6B2437;--po-pt:#FFFDF9;--po-fill1:rgba(226,138,160,.55);--po-fill2:rgba(240,190,204,.04);--po-pop:#FFFFFF;\n  background:var(--po-bg);border:1px solid var(--po-bd);border-radius:22px;padding:18px 18px 14px;color:var(--po-ink);\n  box-shadow:0 1px 0 rgba(255,255,255,.9) inset,0 12px 32px -16px rgba(107,36,55,.30);min-width:0}\nhtml.dark .po{--po-ink:#F6DDE4;--po-soft:#C9A1AC;--po-bg:linear-gradient(180deg,#2E1A20,#26151A);--po-bd:#4A2B34;--po-chip:#3A2229;--po-chip-bd:#523039;--po-field:#33201F;--po-grid:#45292F;--po-line:#F0A3B8;--po-pt:#26151A;--po-fill1:rgba(240,150,176,.40);--po-fill2:rgba(240,150,176,.02);--po-pop:#331E24;box-shadow:0 12px 32px -16px rgba(0,0,0,.6)}\n.po *{box-sizing:border-box}\n.po-head{display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:10px 12px}\n.po-titlewrap{min-width:0}\n.po-title{display:flex;align-items:center;gap:8px;margin:0;font-family:'Playfair Display',Georgia,serif;font-weight:700;font-size:20px;line-height:1.2;color:var(--po-ink)}\n.po-title svg{flex:none}\n.po-range{margin:3px 0 0 28px;font-size:11px;color:var(--po-soft);font-weight:500}\n.po-ctl{display:flex;align-items:center;gap:8px;max-width:100%}\n.po-seg{display:flex;background:var(--po-chip);border:1px solid var(--po-chip-bd);border-radius:999px;padding:3px}\n.po-seg button{border:0;background:transparent;color:var(--po-soft);font:600 12px/1 inherit;font-family:inherit;padding:7px 11px;border-radius:999px;cursor:pointer;white-space:nowrap;transition:background .2s,color .2s}\n.po-seg button.on{background:#6B2437;color:#fff;box-shadow:0 4px 10px -4px rgba(107,36,55,.6)}\nhtml.dark .po-seg button.on{background:#F0A3B8;color:#3A1520}\n.po-cal{flex:none;width:34px;height:34px;border-radius:12px;border:1px solid var(--po-chip-bd);background:var(--po-field);color:var(--po-ink);display:grid;place-items:center;cursor:pointer;padding:0}\n.po-cal.on{background:#6B2437;color:#fff;border-color:#6B2437}\nhtml.dark .po-cal.on{background:#F0A3B8;color:#3A1520;border-color:#F0A3B8}\n.po-pop{margin-top:12px;display:flex;flex-wrap:wrap;gap:10px;align-items:flex-end;padding:12px;background:var(--po-pop);border:1px solid var(--po-bd);border-radius:14px}\n.po-pop[hidden]{display:none}\n.po-pop label{display:grid;gap:4px;font-size:11px;font-weight:600;color:var(--po-soft);flex:1 1 130px;min-width:0}\n.po-pop input{width:100%;border:1px solid var(--po-chip-bd);border-radius:10px;padding:8px 9px;font:inherit;font-size:13px;color:var(--po-ink);background:var(--po-field);min-height:36px}\n.po-go{border:0;border-radius:10px;background:#6B2437;color:#fff;font:600 13px inherit;font-family:inherit;padding:0 16px;min-height:36px;cursor:pointer}\nhtml.dark .po-go{background:#F0A3B8;color:#3A1520}\n.po-err{flex:1 1 100%;margin:0;font-size:12px;color:#B3261E}\nhtml.dark .po-err{color:#FF9C92}\n.po-chart{position:relative;margin-top:10px;width:100%;height:250px;touch-action:pan-y}\n.po-chart svg{display:block;width:100%;height:100%;overflow:visible}\n.po-chart.loading svg{opacity:.35;transition:opacity .2s}\n.po-grid{stroke:var(--po-grid);stroke-width:1;stroke-dasharray:3 5}\n.po-zero{stroke:var(--po-soft);stroke-width:1;opacity:.5}\n.po-tick{fill:var(--po-soft);font-size:10.5px;font-family:inherit}\n.po-line{fill:none;stroke:var(--po-line);stroke-width:2.6;stroke-linecap:round;stroke-linejoin:round}\n.po-dot{fill:var(--po-pt);stroke:var(--po-line);stroke-width:2}\n.po-dot.hot{fill:var(--po-line)}\n.po-guide{stroke:var(--po-line);stroke-width:1;opacity:.35;stroke-dasharray:3 3}\n.po-flag{position:absolute;transform:translate(-50%,-100%);background:#6B2437;color:#fff;border-radius:12px;padding:6px 11px;font-size:13px;font-weight:700;line-height:1.25;box-shadow:0 8px 18px -6px rgba(107,36,55,.55);pointer-events:none;white-space:nowrap;text-align:center;transition:left .12s,top .12s}\n.po-flag small{display:block;opacity:.78;font-size:9.5px;font-weight:600;letter-spacing:.07em;text-transform:uppercase}\n.po-flag:after{content:\"\";position:absolute;left:50%;bottom:-5px;width:10px;height:10px;background:inherit;transform:translateX(-50%) rotate(45deg);border-radius:2px}\nhtml.dark .po-flag{background:#F0A3B8;color:#3A1520}\n.po-empty{position:absolute;inset:0;display:grid;place-items:center;font-size:13px;color:var(--po-soft);text-align:center;padding:20px}\n.po-foot{display:flex;flex-wrap:wrap;gap:6px 20px;margin-top:6px;padding-top:10px;border-top:1px solid var(--po-bd);font-size:12px;color:var(--po-soft)}\n.po-foot b{color:var(--po-ink);font-weight:700;margin-left:4px}\n@media (max-width:480px){.po{padding:14px 12px 12px;border-radius:18px}.po-title{font-size:18px}.po-chart{height:215px}.po-seg button{padding:7px 9px}}\n";
/* ---- pure helpers (shared logic) ---- */
const TZ = 'Africa/Addis_Ababa';
const todayShop = () => new Intl.DateTimeFormat('en-CA', { timeZone: TZ }).format(new Date());
const addDays = (ymd, n) => { const d = new Date(ymd + 'T12:00:00+03:00'); d.setUTCDate(d.getUTCDate() + n); return new Intl.DateTimeFormat('en-CA', { timeZone: TZ }).format(d); };
const dayStartIso = (ymd) => new Date(ymd + 'T00:00:00+03:00').toISOString();
const daysBetween = (a, b) => Math.round((Date.parse(b + 'T12:00:00Z') - Date.parse(a + 'T12:00:00Z')) / 86400000);
const money = (v) => { const n = Number(v) || 0; const s = Math.abs(n).toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 2 }); return n < 0 ? '-ETB ' + s : 'ETB ' + s; };
const shortDay = (ymd) => new Date(ymd + 'T12:00:00Z').toLocaleDateString('en-GB', { day: 'numeric', month: 'short', timeZone: 'UTC' });
const longDay = (ymd) => new Date(ymd + 'T12:00:00Z').toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short', timeZone: 'UTC' });
const compact = (v) => { const a = Math.abs(v); const s = a >= 1e6 ? (a / 1e6).toFixed(a % 1e6 ? 1 : 0) + 'M' : a >= 1e3 ? (a / 1e3).toFixed(a % 1e3 ? 1 : 0) + 'k' : String(Math.round(a)); return (v < 0 ? '-' : '') + s; };
function niceStep(raw) { if (raw <= 0) return 1; const p = Math.pow(10, Math.floor(Math.log10(raw))); const f = raw / p; return (f <= 1 ? 1 : f <= 2 ? 2 : f <= 2.5 ? 2.5 : f <= 5 ? 5 : 10) * p; }
function monotonePath(p) {
  const n = p.length; if (!n) return ''; if (n === 1) return 'M' + p[0].x + ' ' + p[0].y;
  const dx = [], m = [], t = new Array(n);
  for (let i = 0; i < n - 1; i++) { dx[i] = p[i + 1].x - p[i].x; m[i] = (p[i + 1].y - p[i].y) / dx[i]; }
  t[0] = m[0]; t[n - 1] = m[n - 2];
  for (let i = 1; i < n - 1; i++) t[i] = m[i - 1] * m[i] <= 0 ? 0 : (2 * m[i - 1] * m[i]) / (m[i - 1] + m[i]);
  let d = 'M' + p[0].x.toFixed(2) + ' ' + p[0].y.toFixed(2);
  for (let i = 0; i < n - 1; i++) {
    const h = dx[i] / 3;
    d += ' C' + (p[i].x + h).toFixed(2) + ' ' + (p[i].y + t[i] * h).toFixed(2) + ' ' + (p[i + 1].x - h).toFixed(2) + ' ' + (p[i + 1].y - t[i + 1] * h).toFixed(2) + ' ' + p[i + 1].x.toFixed(2) + ' ' + p[i + 1].y.toFixed(2);
  }
  return d;
}
/* profit per day = sales - expenses (voided rows are already excluded by report_summary) */
const toPoints = (daily) => daily.map((d) => ({ day: d.day, sales: Number(d.sales) || 0, expenses: Number(d.expenses) || 0, profit: (Number(d.sales) || 0) - (Number(d.expenses) || 0) }));
function layout(points, W, H) {
  const padL = 46, padR = 16, padT = 44, padB = 28, iw = Math.max(10, W - padL - padR), ih = Math.max(10, H - padT - padB);
  const vals = points.map((p) => p.profit);
  let lo = Math.min(0, ...vals), hi = Math.max(0, ...vals);
  if (hi === lo) hi = lo + 1;
  const step = niceStep((hi - lo) / 4);
  lo = Math.floor(lo / step) * step; hi = Math.ceil(hi / step) * step;
  const ticks = []; for (let v = lo; v <= hi + step / 2; v += step) ticks.push(Math.round(v * 100) / 100);
  const X = (i) => points.length === 1 ? padL + iw / 2 : padL + (iw * i) / (points.length - 1);
  const Y = (v) => padT + ih - ((v - lo) / (hi - lo)) * ih;
  return { padL, padR, padT, padB, iw, ih, ticks, X, Y, lo, hi };
}

const URL_ = 'https://ucyicnxykdvxbbgokxcq.supabase.co';
const KEY = 'sb_publishable_0cw1I4TINn_CkH9yhbF53g_10e8vfV6';
const SKEY = 'sb-ucyicnxykdvxbbgokxcq-auth-token';
const NS = 'http://www.w3.org/2000/svg';
const state = { preset: 7, from: '', to: '' }; // survives re-renders of the dashboard
let seq = 0;

function session() { try { const s = JSON.parse(localStorage.getItem(SKEY) || 'null'); return s && s.access_token ? (s.currentSession || s) : null; } catch (e) { return null; } }
async function fetchDaily(from, to, retry) {
  const s = session(); if (!s) throw new Error('Not signed in');
  const res = await fetch(URL_ + '/rest/v1/rpc/report_summary', { method: 'POST', headers: { apikey: KEY, Authorization: 'Bearer ' + s.access_token, 'Content-Type': 'application/json' }, body: JSON.stringify({ p_from: dayStartIso(from), p_to: dayStartIso(addDays(to, 1)) }) });
  if (res.status === 401 && !retry) { await new Promise((r) => setTimeout(r, 1500)); return fetchDaily(from, to, true); }
  if (!res.ok) throw new Error(res.status === 403 || res.status === 401 ? "You don't have permission to see this." : 'Could not load profit. Check your connection.');
  const j = await res.json();
  return { daily: j.daily || [], totals: j.totals || {} };
}
const el = (tag, attrs, html) => { const e = document.createElement(tag); if (attrs) for (const k in attrs) e.setAttribute(k, attrs[k]); if (html != null) e.innerHTML = html; return e; };
const sv = (tag, attrs) => { const e = document.createElementNS(NS, tag); for (const k in attrs) e.setAttribute(k, attrs[k]); return e; };

function range() { return state.preset === 'custom' ? { from: state.from, to: state.to } : { from: addDays(todayShop(), -(state.preset - 1)), to: todayShop() }; }

function build() {
  const root = el('section', { class: 'po', 'data-testid': 'profit-overview', 'aria-label': 'Profit Overview' });
  root.innerHTML =
    '<div class="po-head"><div class="po-titlewrap"><h2 class="po-title"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 3v18h18"/><path d="M7 15l4-4 3 3 5-6"/></svg>Profit Overview</h2><p class="po-range"></p></div>' +
    '<div class="po-ctl"><div class="po-seg" role="group" aria-label="Time range"><button type="button" data-p="7">7 Days</button><button type="button" data-p="30">30 Days</button><button type="button" data-p="90">90 Days</button></div>' +
    '<button type="button" class="po-cal" aria-label="Choose custom dates" title="Custom dates" aria-expanded="false"><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4.5" width="18" height="16.5" rx="3"/><path d="M8 2.5v4M16 2.5v4M3 10h18"/></svg></button></div></div>' +
    '<div class="po-pop" hidden><label>From<input type="date" class="po-from"></label><label>To<input type="date" class="po-to"></label><button type="button" class="po-go">Apply</button><p class="po-err" hidden></p></div>' +
    '<div class="po-chart loading"></div>' +
    '<div class="po-foot"><span>Revenue<b class="po-rev">–</b></span><span>Expenses<b class="po-exp">–</b></span></div>';
  const q = (s) => root.querySelector(s);
  const chart = q('.po-chart'), pop = q('.po-pop'), cal = q('.po-cal'), err = q('.po-err');
  let points = [], width = 0, loadErr = '', busy = true;

  function syncUi() {
    root.querySelectorAll('.po-seg button').forEach((b) => b.classList.toggle('on', String(state.preset) === b.dataset.p));
    cal.classList.toggle('on', state.preset === 'custom');
    const r = range(); q('.po-range').textContent = r.from === r.to ? longDay(r.from) : shortDay(r.from) + ' – ' + shortDay(r.to) + (r.to.slice(0, 4) !== r.from.slice(0, 4) ? ' ' + r.to.slice(0, 4) : '');
    const t = todayShop(); q('.po-from').max = t; q('.po-to').max = t;
  }
  function draw() {
    chart.className = 'po-chart' + (busy ? ' loading' : '');
    chart.innerHTML = '';
    const W = chart.clientWidth || width || 600, H = chart.clientHeight || 250; width = W;
    if (loadErr) { chart.appendChild(el('div', { class: 'po-empty' }, '')).textContent = loadErr; return; }
    if (!points.length) { if (!busy) chart.appendChild(el('div', { class: 'po-empty' }, 'No data for this period.')); return; }
    const L = layout(points, W, H), base = L.Y(0);
    const svg = sv('svg', { viewBox: '0 0 ' + W + ' ' + H, width: W, height: H, role: 'img', 'aria-label': 'Profit per day' });
    const defs = sv('defs', {}); const gr = sv('linearGradient', { id: 'po-g', x1: '0', y1: '0', x2: '0', y2: '1' });
    gr.appendChild(sv('stop', { offset: '0', style: 'stop-color:var(--po-fill1)' })); gr.appendChild(sv('stop', { offset: '1', style: 'stop-color:var(--po-fill2)' })); defs.appendChild(gr); svg.appendChild(defs);
    L.ticks.forEach((v) => { const y = L.Y(v); svg.appendChild(sv('line', { class: v === 0 ? 'po-zero' : 'po-grid', x1: L.padL, x2: W - L.padR, y1: y, y2: y })); const t = sv('text', { class: 'po-tick', x: L.padL - 8, y: y + 3.5, 'text-anchor': 'end' }); t.textContent = compact(v); svg.appendChild(t); });
    const n = points.length, cnt = Math.min(n, W < 420 ? 4 : W < 760 ? 6 : 8);
    const idx = n === 1 ? [0] : n <= (W < 420 ? 7 : 10) ? points.map((_, i) => i) : Array.from({ length: cnt }, (_, k) => Math.round((k * (n - 1)) / (cnt - 1)));
    idx.filter((v, k) => idx.indexOf(v) === k).forEach((i, k, a) => { const t = sv('text', { class: 'po-tick', x: L.X(i), y: H - 6, 'text-anchor': i === 0 && n > 1 ? 'start' : i === n - 1 && n > 1 ? 'end' : 'middle' }); t.textContent = shortDay(points[i].day); svg.appendChild(t); });
    const pts = points.map((p, i) => ({ x: L.X(i), y: L.Y(p.profit) }));
    const d = monotonePath(pts);
    if (n > 1) { svg.appendChild(sv('path', { d: d + ' L' + pts[n - 1].x + ' ' + base + ' L' + pts[0].x + ' ' + base + ' Z', fill: 'url(#po-g)', stroke: 'none' })); svg.appendChild(sv('path', { class: 'po-line', d })); }
    const r = n <= 14 ? 4.5 : n <= 31 ? 3.6 : 2.6;
    const dots = pts.map((p) => { const c = sv('circle', { class: 'po-dot', cx: p.x, cy: p.y, r }); svg.appendChild(c); return c; });
    const guide = sv('line', { class: 'po-guide', y1: L.padT - 6, y2: H - L.padB, x1: 0, x2: 0, visibility: 'hidden' }); svg.appendChild(guide);
    chart.appendChild(svg);
    const total = points.reduce((s, p) => s + p.profit, 0);
    let peak = 0; points.forEach((p, i) => { if (p.profit >= points[peak].profit) peak = i; });
    const flag = el('div', { class: 'po-flag', 'data-testid': 'po-total' }); chart.appendChild(flag);
    const place = (i, html) => { flag.innerHTML = html; const x = Math.min(Math.max(pts[i].x, 62), W - 62); flag.style.left = x + 'px'; flag.style.top = Math.max(34, pts[i].y - 12) + 'px'; };
    const showTotal = () => { dots.forEach((c) => c.classList.remove('hot')); guide.setAttribute('visibility', 'hidden'); place(peak, '<small>Total profit</small>' + money(total)); };
    showTotal();
    const move = (ev) => { const b = svg.getBoundingClientRect(); const x = ev.clientX - b.left; let best = 0, bd = 1e9; pts.forEach((p, i) => { const dd = Math.abs(p.x - x); if (dd < bd) { bd = dd; best = i; } });
      dots.forEach((c, i) => c.classList.toggle('hot', i === best)); guide.setAttribute('x1', pts[best].x); guide.setAttribute('x2', pts[best].x); guide.setAttribute('visibility', 'visible');
      place(best, '<small>' + longDay(points[best].day) + '</small>' + money(points[best].profit)); };
    chart.onpointermove = move; chart.onpointerdown = move; chart.onpointerleave = showTotal;
  }
  async function load() {
    const my = ++seq, r = range(); busy = true; loadErr = ''; syncUi(); draw();
    try {
      const { daily, totals } = await fetchDaily(r.from, r.to);
      if (my !== seq) return;
      points = toPoints(daily); busy = false;
      q('.po-rev').textContent = money(points.reduce((s, p) => s + p.sales, 0)); q('.po-exp').textContent = money(points.reduce((s, p) => s + p.expenses, 0));
    } catch (e) { if (my !== seq) return; points = []; busy = false; loadErr = e.message; q('.po-rev').textContent = '–'; q('.po-exp').textContent = '–'; }
    draw();
  }
  root.querySelectorAll('.po-seg button').forEach((b) => b.addEventListener('click', () => { state.preset = Number(b.dataset.p); pop.hidden = true; cal.setAttribute('aria-expanded', 'false'); load(); }));
  cal.addEventListener('click', () => { const open = pop.hidden; pop.hidden = !open; cal.setAttribute('aria-expanded', String(open)); if (open) { const r = range(); q('.po-from').value = r.from; q('.po-to').value = r.to; err.hidden = true; } });
  q('.po-go').addEventListener('click', () => {
    const f = q('.po-from').value, t = q('.po-to').value, today = todayShop(); let m = '';
    if (!f || !t) m = 'Choose both dates.'; else if (f > t) m = 'The start date must be before the end date.'; else if (t > today) m = 'The end date cannot be in the future.'; else if (daysBetween(f, t) > 365) m = 'Choose a range of up to 366 days.';
    if (m) { err.textContent = m; err.hidden = false; return; }
    err.hidden = true; state.preset = 'custom'; state.from = f; state.to = t; pop.hidden = true; cal.setAttribute('aria-expanded', 'false'); load();
  });
  if (window.ResizeObserver) new ResizeObserver(() => { if (chart.clientWidth && Math.abs(chart.clientWidth - width) > 1) draw(); }).observe(chart);
  root._load = load; return root;
}

/* ---- attach: replace the Net profit ring wherever it appears ---- */
let mounted = null, timer = null;
function attach() {
  const svg = document.querySelector('svg[role="img"][aria-label^="Net profit"]');
  if (!svg) return;
  const ring = svg.parentElement && svg.parentElement.parentElement;
  if (!ring || !ring.parentElement) return;
  if (mounted && mounted.isConnected && mounted.nextElementSibling === ring) return;
  if (mounted) mounted.remove();
  ring.style.display = 'none'; ring.setAttribute('data-po-hidden', '1');
  mounted = build(); ring.parentElement.insertBefore(mounted, ring);
  mounted._load();
}
const st = document.createElement('style'); st.textContent = CSS_TEXT; document.head.appendChild(st);
new MutationObserver(() => { clearTimeout(timer); timer = setTimeout(attach, 50); }).observe(document.documentElement, { childList: true, subtree: true });
attach();

})();
