-- Driver login role. Run ONCE in Supabase > SQL Editor.
-- A driver stays an "employee" in the database (so deliveries keep working),
-- and is flagged is_driver. The app then shows drivers ONLY the Deliveries page.
alter table public.profiles add column if not exists is_driver boolean not null default false;

create or replace function public.set_driver_login(p_id uuid, p_on boolean)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if not exists (select 1 from public.profiles where id = auth.uid() and role = 'owner' and active) then
    raise exception 'Only the owner can change driver logins';
  end if;
  update public.profiles
     set is_driver = p_on
   where id = p_id and role = 'employee';
  if not found then
    raise exception 'Driver logins must be employee accounts';
  end if;
end $$;

revoke all on function public.set_driver_login(uuid, boolean) from public;
grant execute on function public.set_driver_login(uuid, boolean) to authenticated;
