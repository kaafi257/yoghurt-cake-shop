/* SweetCraft: adds "Scan QR" (everyone) and "Products" (owner) to the side menu, plus a floating Scan QR button. */
(function(){'use strict';
/* pop-ups: always centred and fully visible (works with the built app too) */
try{var st=document.createElement('style');st.id='sc-popup-fix';st.textContent='.sheet-backdrop{align-items:center!important;justify-content:center!important;padding:max(16px,env(safe-area-inset-top,0px)) 16px max(16px,env(safe-area-inset-bottom,0px))!important;overflow:hidden!important}.sheet-card{box-sizing:border-box!important;border-radius:22px!important;max-height:calc(100dvh - 32px - env(safe-area-inset-top,0px) - env(safe-area-inset-bottom,0px))!important;margin:auto!important;padding-bottom:20px!important;box-shadow:0 24px 70px rgba(30,15,18,.35);animation-name:sheetPop!important}';document.head.appendChild(st)}catch(e){}
var ICON={
 qr:'<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><path d="M14 14h3v3h-3zM20 14v.01M14 20h.01M17 20h4v-3"/></svg>',
 bag:'<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><path d="M3 6h18"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>',
 cash:'<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="6" width="20" height="13" rx="3"/><circle cx="12" cy="12.5" r="2.8"/><path d="M6 10v5M18 10v5"/></svg>',
 tag:'<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.6 13.4l-7.2 7.2a2 2 0 0 1-2.8 0L3 13V3h10l7.6 7.6a2 2 0 0 1 0 2.8z"/><circle cx="7.5" cy="7.5" r="1.2"/></svg>'};

function addItem(nav,tpl,href,title,icon,key){
  if(nav.querySelector('[data-sc="'+key+'"]'))return;
  var w=tpl.cloneNode(true);w.setAttribute('data-sc',key);
  var a=w.querySelector('a');if(!a)return;
  a.setAttribute('href',href);a.classList.remove('active');a.removeAttribute('aria-current');
  a.innerHTML='<span class="ic">'+icon+'</span>'+title;
  nav.appendChild(w);
}
function patchDrawer(){
  var d=document.querySelector('.drawer');if(!d)return;
  var nav=d.querySelector('nav');if(!nav)return;
  var items=nav.children;if(!items.length)return;
  var tpl=items[items.length-1];
  if(tpl.getAttribute('data-sc')){tpl=items[0]}
  var roleEl=d.querySelector('span[style*="capitalize"]');
  var role=roleEl?roleEl.textContent.trim().toLowerCase():'';
  addItem(nav,tpl,'/qr/','Scan QR',ICON.qr,'qr');
  if(role==='owner'||role==='manager')addItem(nav,tpl,'/salary/','Salary',ICON.cash,'salary');
}
function fab(){
  if(document.getElementById('sc-qr-fab'))return;
  var a=document.createElement('a');a.id='sc-qr-fab';a.href='/qr/';a.textContent='Scan QR';
  a.style.cssText='position:fixed;right:14px;bottom:calc(16px + env(safe-area-inset-bottom,0px));z-index:30;background:#6B1D2F;color:#fff;font:700 14px system-ui,sans-serif;padding:13px 18px;border-radius:999px;text-decoration:none;box-shadow:0 8px 22px rgba(107,29,47,.35);display:none';
  document.body.appendChild(a);
}
function sync(){
  var a=document.getElementById('sc-qr-fab');
  if(a)a.style.display=/^\/(login|reset-password)/.test(location.pathname)?'none':'block';
  patchDrawer();
}
function start(){fab();sync();new MutationObserver(sync).observe(document.body,{childList:true,subtree:true});setInterval(sync,1000)}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();

/* notifications: load the bell on every main-app page (works even if index.html was not rebuilt) */
try{if(!window.SCNotify&&!document.getElementById('sc-notify-js')){var ns=document.createElement('script');ns.id='sc-notify-js';ns.src='/notify.js?v=3';ns.async=true;document.head.appendChild(ns)}}catch(e){}
})();
