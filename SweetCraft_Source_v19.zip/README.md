# SweetCraft — project source (v19)

## What is here
- `SweetCraft_site/`        the full website (main app + all pages). Deploy this folder.
- `SweetCraft_store_site/`  store-only copy (optional, for a separate host).

## Readable, editable source (plain HTML / JS / CSS)
| Path | What it is |
|---|---|
| `shop/` | Customer online store |
| `track/` | Order tracking page |
| `orders/` | Online orders manager (owner / manager) |
| `delivery/` | Delivery board + driver mode (`drive.js`, `map.js`, `map.css`) |
| `online/` | Online Hub (store info, pipeline, drivers, map, activity) |
| `reports-app/` | Reports app (`js/api.js`, `js/config.js`) |
| `salary/`, `qr/` | Salary and QR scanner pages |
| `notify.js`, `qr-link.js`, `profile-pics.js`, `profit-overview.js`, `fresh.js` | Shared scripts |
| `runtime-config.js` | Supabase URL and public (publishable) key |
| `supabase/Driver_Login_SQL.sql` | Database script for the Driver login role |
| `vercel.json`, `_redirects`, `_headers` | Hosting settings (Vercel / Netlify) |
| `manifest.webmanifest`, `sw.js`, `mgr-*.png` | Main app install settings and icons |

## Compiled (NOT original source)
`assets/index-Hub*.js` is the main app (Today, Sale, Expense, History, Stock, Staff,
Activity log) already built into one file. The original React project (src/, package.json)
was not provided, so it cannot be included. It can be edited, but only with care.
To get the original source, ask for it in the chat where the main app was first built.

## Backend
Supabase project (database, login, RPC functions). Not in this folder except the
SQL script above. Back up the database from the Supabase dashboard.

## Deploy
Upload the contents of `SweetCraft_site/` (index.html must be at the top level).
Store address on Vercel: add domain `sweetcraft-store.vercel.app` to the same project.
